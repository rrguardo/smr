package io.swagger.client.api;

import com.sun.jersey.api.client.GenericType;

import io.swagger.client.ApiException;
import io.swagger.client.ApiClient;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;

import io.swagger.client.model.Error;
import io.swagger.client.model.Balance;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaClientCodegen", date = "2016-03-14T05:28:05.393Z")
public class GetBalanceApi {
  private ApiClient apiClient;

  public GetBalanceApi() {
    this(Configuration.getDefaultApiClient());
  }

  public GetBalanceApi(ApiClient apiClient) {
    this.apiClient = apiClient;
  }

  public ApiClient getApiClient() {
    return apiClient;
  }

  public void setApiClient(ApiClient apiClient) {
    this.apiClient = apiClient;
  }

  
  /**
   * Get account balance
   * Use this API endpoint to get account balance.
   * @param userId The user account id, located at user panel.
   * @param authToken The user authentication token, located at user panel.
   * @return Balance
   * @throws ApiException if fails to make API call
   */
  public Balance balancePost(Integer userId, String authToken) throws ApiException {
    Object localVarPostBody = null;
    
    // verify the required parameter 'userId' is set
    if (userId == null) {
      throw new ApiException(400, "Missing the required parameter 'userId' when calling balancePost");
    }
    
    // verify the required parameter 'authToken' is set
    if (authToken == null) {
      throw new ApiException(400, "Missing the required parameter 'authToken' when calling balancePost");
    }
    
    // create path and map variables
    String localVarPath = "/balance".replaceAll("\\{format\\}","json");

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();

    

    

    if (userId != null)
      localVarFormParams.put("user_id", userId);
    if (authToken != null)
      localVarFormParams.put("auth_token", authToken);
    

    final String[] localVarAccepts = {
      "application/json"
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      "application/x-www-form-urlencoded"
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    
    GenericType<Balance> localVarReturnType = new GenericType<Balance>() {};
    return apiClient.invokeAPI(localVarPath, "POST", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    
  }
  
}
