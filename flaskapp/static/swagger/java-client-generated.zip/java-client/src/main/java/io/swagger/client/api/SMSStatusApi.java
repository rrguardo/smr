package io.swagger.client.api;

import com.sun.jersey.api.client.GenericType;

import io.swagger.client.ApiException;
import io.swagger.client.ApiClient;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;

import io.swagger.client.model.SMSStatus;
import io.swagger.client.model.Error;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaClientCodegen", date = "2016-03-14T05:28:05.393Z")
public class SMSStatusApi {
  private ApiClient apiClient;

  public SMSStatusApi() {
    this(Configuration.getDefaultApiClient());
  }

  public SMSStatusApi(ApiClient apiClient) {
    this.apiClient = apiClient;
  }

  public ApiClient getApiClient() {
    return apiClient;
  }

  public void setApiClient(ApiClient apiClient) {
    this.apiClient = apiClient;
  }

  
  /**
   * Verify SMS sent status
   * Use this API endpoint to verify SMS sent status.
   * @param userId The user account id, located at user panel.
   * @param authToken The user authentication token, located at user panel.
   * @param pid The processing id pid returned when you sent the sms.
   * @return SMSStatus
   * @throws ApiException if fails to make API call
   */
  public SMSStatus statusPost(Integer userId, String authToken, Integer pid) throws ApiException {
    Object localVarPostBody = null;
    
    // verify the required parameter 'userId' is set
    if (userId == null) {
      throw new ApiException(400, "Missing the required parameter 'userId' when calling statusPost");
    }
    
    // verify the required parameter 'authToken' is set
    if (authToken == null) {
      throw new ApiException(400, "Missing the required parameter 'authToken' when calling statusPost");
    }
    
    // verify the required parameter 'pid' is set
    if (pid == null) {
      throw new ApiException(400, "Missing the required parameter 'pid' when calling statusPost");
    }
    
    // create path and map variables
    String localVarPath = "/status".replaceAll("\\{format\\}","json");

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();

    

    

    if (userId != null)
      localVarFormParams.put("user_id", userId);
    if (authToken != null)
      localVarFormParams.put("auth_token", authToken);
    if (pid != null)
      localVarFormParams.put("pid", pid);
    

    final String[] localVarAccepts = {
      "application/json"
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      "application/x-www-form-urlencoded"
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    
    GenericType<SMSStatus> localVarReturnType = new GenericType<SMSStatus>() {};
    return apiClient.invokeAPI(localVarPath, "POST", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    
  }
  
}
