package io.swagger.client.api;

import com.sun.jersey.api.client.GenericType;

import io.swagger.client.ApiException;
import io.swagger.client.ApiClient;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;

import io.swagger.client.model.SMSResponse;
import io.swagger.client.model.Error;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaClientCodegen", date = "2016-03-14T05:28:05.393Z")
public class SendSMSApi {
  private ApiClient apiClient;

  public SendSMSApi() {
    this(Configuration.getDefaultApiClient());
  }

  public SendSMSApi(ApiClient apiClient) {
    this.apiClient = apiClient;
  }

  public ApiClient getApiClient() {
    return apiClient;
  }

  public void setApiClient(ApiClient apiClient) {
    this.apiClient = apiClient;
  }

  
  /**
   * Send SMS text message
   * Use this API endpoint to send SMS text messages.
   * @param userId The user account id, located at user panel.
   * @param authToken The user authentication token, located at user panel.
   * @param to The phone number where send the SMS.
   * @param body The SMS text message to send.
   * @return SMSResponse
   * @throws ApiException if fails to make API call
   */
  public SMSResponse smsPost(Integer userId, String authToken, String to, String body) throws ApiException {
    Object localVarPostBody = null;
    
    // verify the required parameter 'userId' is set
    if (userId == null) {
      throw new ApiException(400, "Missing the required parameter 'userId' when calling smsPost");
    }
    
    // verify the required parameter 'authToken' is set
    if (authToken == null) {
      throw new ApiException(400, "Missing the required parameter 'authToken' when calling smsPost");
    }
    
    // verify the required parameter 'to' is set
    if (to == null) {
      throw new ApiException(400, "Missing the required parameter 'to' when calling smsPost");
    }
    
    // verify the required parameter 'body' is set
    if (body == null) {
      throw new ApiException(400, "Missing the required parameter 'body' when calling smsPost");
    }
    
    // create path and map variables
    String localVarPath = "/sms".replaceAll("\\{format\\}","json");

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();

    

    

    if (userId != null)
      localVarFormParams.put("user_id", userId);
    if (authToken != null)
      localVarFormParams.put("auth_token", authToken);
    if (to != null)
      localVarFormParams.put("to", to);
    if (body != null)
      localVarFormParams.put("body", body);
    

    final String[] localVarAccepts = {
      "application/json"
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      "application/x-www-form-urlencoded"
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    
    GenericType<SMSResponse> localVarReturnType = new GenericType<SMSResponse>() {};
    return apiClient.invokeAPI(localVarPath, "POST", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    
  }
  
}
