using System;
using System.IO;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ISendSMSApi
    {
        #region Synchronous Operations
        
        /// <summary>
        /// Send SMS text message
        /// </summary>
        /// <remarks>
        /// Use this API endpoint to send SMS text messages.
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="userId">The user account id, located at user panel.</param>
        /// <param name="authToken">The user authentication token, located at user panel.</param>
        /// <param name="to">The phone number where send the SMS.</param>
        /// <param name="body">The SMS text message to send.</param>
        /// <returns>SMSResponse</returns>
        SMSResponse SmsPost (int? userId, string authToken, string to, string body);
  
        /// <summary>
        /// Send SMS text message
        /// </summary>
        /// <remarks>
        /// Use this API endpoint to send SMS text messages.
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="userId">The user account id, located at user panel.</param>
        /// <param name="authToken">The user authentication token, located at user panel.</param>
        /// <param name="to">The phone number where send the SMS.</param>
        /// <param name="body">The SMS text message to send.</param>
        /// <returns>ApiResponse of SMSResponse</returns>
        ApiResponse<SMSResponse> SmsPostWithHttpInfo (int? userId, string authToken, string to, string body);
        
        #endregion Synchronous Operations
        
        #region Asynchronous Operations
        
        /// <summary>
        /// Send SMS text message
        /// </summary>
        /// <remarks>
        /// Use this API endpoint to send SMS text messages.
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="userId">The user account id, located at user panel.</param>
        /// <param name="authToken">The user authentication token, located at user panel.</param>
        /// <param name="to">The phone number where send the SMS.</param>
        /// <param name="body">The SMS text message to send.</param>
        /// <returns>Task of SMSResponse</returns>
        System.Threading.Tasks.Task<SMSResponse> SmsPostAsync (int? userId, string authToken, string to, string body);

        /// <summary>
        /// Send SMS text message
        /// </summary>
        /// <remarks>
        /// Use this API endpoint to send SMS text messages.
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="userId">The user account id, located at user panel.</param>
        /// <param name="authToken">The user authentication token, located at user panel.</param>
        /// <param name="to">The phone number where send the SMS.</param>
        /// <param name="body">The SMS text message to send.</param>
        /// <returns>Task of ApiResponse (SMSResponse)</returns>
        System.Threading.Tasks.Task<ApiResponse<SMSResponse>> SmsPostAsyncWithHttpInfo (int? userId, string authToken, string to, string body);
        
        #endregion Asynchronous Operations
        
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class SendSMSApi : ISendSMSApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SendSMSApi"/> class.
        /// </summary>
        /// <returns></returns>
        public SendSMSApi(String basePath)
        {
            this.Configuration = new Configuration(new ApiClient(basePath));
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="SendSMSApi"/> class
        /// using Configuration object
        /// </summary>
        /// <param name="configuration">An instance of Configuration</param>
        /// <returns></returns>
        public SendSMSApi(Configuration configuration = null)
        {
            if (configuration == null) // use the default one in Configuration
                this.Configuration = Configuration.Default; 
            else
                this.Configuration = configuration;
        }

        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <value>The base path</value>
        public String GetBasePath()
        {
            return this.Configuration.ApiClient.RestClient.BaseUrl.ToString();
        }

        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <value>The base path</value>
        [Obsolete("SetBasePath is deprecated, please do 'Configuraiton.ApiClient = new ApiClient(\"http://new-path\")' instead.")]
        public void SetBasePath(String basePath)
        {
            // do nothing
        }
    
        /// <summary>
        /// Gets or sets the configuration object
        /// </summary>
        /// <value>An instance of the Configuration</value>
        public Configuration Configuration {get; set;}

        /// <summary>
        /// Gets the default header.
        /// </summary>
        /// <returns>Dictionary of HTTP header</returns>
        [Obsolete("DefaultHeader is deprecated, please use Configuration.DefaultHeader instead.")]
        public Dictionary<String, String> DefaultHeader()
        {
            return this.Configuration.DefaultHeader;
        }

        /// <summary>
        /// Add default header.
        /// </summary>
        /// <param name="key">Header field name.</param>
        /// <param name="value">Header field value.</param>
        /// <returns></returns>
        [Obsolete("AddDefaultHeader is deprecated, please use Configuration.AddDefaultHeader instead.")]
        public void AddDefaultHeader(string key, string value)
        {
            this.Configuration.AddDefaultHeader(key, value);
        }
   
        
        /// <summary>
        /// Send SMS text message Use this API endpoint to send SMS text messages.
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="userId">The user account id, located at user panel.</param> 
        /// <param name="authToken">The user authentication token, located at user panel.</param> 
        /// <param name="to">The phone number where send the SMS.</param> 
        /// <param name="body">The SMS text message to send.</param> 
        /// <returns>SMSResponse</returns>
        public SMSResponse SmsPost (int? userId, string authToken, string to, string body)
        {
             ApiResponse<SMSResponse> localVarResponse = SmsPostWithHttpInfo(userId, authToken, to, body);
             return localVarResponse.Data;
        }

        /// <summary>
        /// Send SMS text message Use this API endpoint to send SMS text messages.
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="userId">The user account id, located at user panel.</param> 
        /// <param name="authToken">The user authentication token, located at user panel.</param> 
        /// <param name="to">The phone number where send the SMS.</param> 
        /// <param name="body">The SMS text message to send.</param> 
        /// <returns>ApiResponse of SMSResponse</returns>
        public ApiResponse< SMSResponse > SmsPostWithHttpInfo (int? userId, string authToken, string to, string body)
        {
            
            // verify the required parameter 'userId' is set
            if (userId == null)
                throw new ApiException(400, "Missing required parameter 'userId' when calling SendSMSApi->SmsPost");
            
            // verify the required parameter 'authToken' is set
            if (authToken == null)
                throw new ApiException(400, "Missing required parameter 'authToken' when calling SendSMSApi->SmsPost");
            
            // verify the required parameter 'to' is set
            if (to == null)
                throw new ApiException(400, "Missing required parameter 'to' when calling SendSMSApi->SmsPost");
            
            // verify the required parameter 'body' is set
            if (body == null)
                throw new ApiException(400, "Missing required parameter 'body' when calling SendSMSApi->SmsPost");
            
    
            var localVarPath = "/sms";
    
            var localVarPathParams = new Dictionary<String, String>();
            var localVarQueryParams = new Dictionary<String, String>();
            var localVarHeaderParams = new Dictionary<String, String>(Configuration.DefaultHeader);
            var localVarFormParams = new Dictionary<String, String>();
            var localVarFileParams = new Dictionary<String, FileParameter>();
            Object localVarPostBody = null;

            // to determine the Content-Type header
            String[] localVarHttpContentTypes = new String[] {
                "application/x-www-form-urlencoded"
            };
            String localVarHttpContentType = Configuration.ApiClient.SelectHeaderContentType(localVarHttpContentTypes);

            // to determine the Accept header
            String[] localVarHttpHeaderAccepts = new String[] {
                "application/json"
            };
            String localVarHttpHeaderAccept = Configuration.ApiClient.SelectHeaderAccept(localVarHttpHeaderAccepts);
            if (localVarHttpHeaderAccept != null)
                localVarHeaderParams.Add("Accept", localVarHttpHeaderAccept);

            // set "format" to json by default
            // e.g. /pet/{petId}.{format} becomes /pet/{petId}.json
            localVarPathParams.Add("format", "json");
            
            
            
            if (userId != null) localVarFormParams.Add("user_id", Configuration.ApiClient.ParameterToString(userId)); // form parameter
            if (authToken != null) localVarFormParams.Add("auth_token", Configuration.ApiClient.ParameterToString(authToken)); // form parameter
            if (to != null) localVarFormParams.Add("to", Configuration.ApiClient.ParameterToString(to)); // form parameter
            if (body != null) localVarFormParams.Add("body", Configuration.ApiClient.ParameterToString(body)); // form parameter
            
            

            
    
            // make the HTTP request
            IRestResponse localVarResponse = (IRestResponse) Configuration.ApiClient.CallApi(localVarPath, 
                Method.POST, localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarFileParams,
                localVarPathParams, localVarHttpContentType);

            int localVarStatusCode = (int) localVarResponse.StatusCode;
    
            if (localVarStatusCode >= 400)
                throw new ApiException (localVarStatusCode, "Error calling SmsPost: " + localVarResponse.Content, localVarResponse.Content);
            else if (localVarStatusCode == 0)
                throw new ApiException (localVarStatusCode, "Error calling SmsPost: " + localVarResponse.ErrorMessage, localVarResponse.ErrorMessage);
    
            return new ApiResponse<SMSResponse>(localVarStatusCode,
                localVarResponse.Headers.ToDictionary(x => x.Name, x => x.Value.ToString()),
                (SMSResponse) Configuration.ApiClient.Deserialize(localVarResponse, typeof(SMSResponse)));
            
        }

        
        /// <summary>
        /// Send SMS text message Use this API endpoint to send SMS text messages.
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="userId">The user account id, located at user panel.</param>
        /// <param name="authToken">The user authentication token, located at user panel.</param>
        /// <param name="to">The phone number where send the SMS.</param>
        /// <param name="body">The SMS text message to send.</param>
        /// <returns>Task of SMSResponse</returns>
        public async System.Threading.Tasks.Task<SMSResponse> SmsPostAsync (int? userId, string authToken, string to, string body)
        {
             ApiResponse<SMSResponse> localVarResponse = await SmsPostAsyncWithHttpInfo(userId, authToken, to, body);
             return localVarResponse.Data;

        }

        /// <summary>
        /// Send SMS text message Use this API endpoint to send SMS text messages.
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="userId">The user account id, located at user panel.</param>
        /// <param name="authToken">The user authentication token, located at user panel.</param>
        /// <param name="to">The phone number where send the SMS.</param>
        /// <param name="body">The SMS text message to send.</param>
        /// <returns>Task of ApiResponse (SMSResponse)</returns>
        public async System.Threading.Tasks.Task<ApiResponse<SMSResponse>> SmsPostAsyncWithHttpInfo (int? userId, string authToken, string to, string body)
        {
            // verify the required parameter 'userId' is set
            if (userId == null) throw new ApiException(400, "Missing required parameter 'userId' when calling SmsPost");
            // verify the required parameter 'authToken' is set
            if (authToken == null) throw new ApiException(400, "Missing required parameter 'authToken' when calling SmsPost");
            // verify the required parameter 'to' is set
            if (to == null) throw new ApiException(400, "Missing required parameter 'to' when calling SmsPost");
            // verify the required parameter 'body' is set
            if (body == null) throw new ApiException(400, "Missing required parameter 'body' when calling SmsPost");
            
    
            var localVarPath = "/sms";
    
            var localVarPathParams = new Dictionary<String, String>();
            var localVarQueryParams = new Dictionary<String, String>();
            var localVarHeaderParams = new Dictionary<String, String>(Configuration.DefaultHeader);
            var localVarFormParams = new Dictionary<String, String>();
            var localVarFileParams = new Dictionary<String, FileParameter>();
            Object localVarPostBody = null;

            // to determine the Content-Type header
            String[] localVarHttpContentTypes = new String[] {
                "application/x-www-form-urlencoded"
            };
            String localVarHttpContentType = Configuration.ApiClient.SelectHeaderContentType(localVarHttpContentTypes);

            // to determine the Accept header
            String[] localVarHttpHeaderAccepts = new String[] {
                "application/json"
            };
            String localVarHttpHeaderAccept = Configuration.ApiClient.SelectHeaderAccept(localVarHttpHeaderAccepts);
            if (localVarHttpHeaderAccept != null)
                localVarHeaderParams.Add("Accept", localVarHttpHeaderAccept);

            // set "format" to json by default
            // e.g. /pet/{petId}.{format} becomes /pet/{petId}.json
            localVarPathParams.Add("format", "json");
            
            
            
            if (userId != null) localVarFormParams.Add("user_id", Configuration.ApiClient.ParameterToString(userId)); // form parameter
            if (authToken != null) localVarFormParams.Add("auth_token", Configuration.ApiClient.ParameterToString(authToken)); // form parameter
            if (to != null) localVarFormParams.Add("to", Configuration.ApiClient.ParameterToString(to)); // form parameter
            if (body != null) localVarFormParams.Add("body", Configuration.ApiClient.ParameterToString(body)); // form parameter
            
            

            

            // make the HTTP request
            IRestResponse localVarResponse = (IRestResponse) await Configuration.ApiClient.CallApiAsync(localVarPath, 
                Method.POST, localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarFileParams, 
                localVarPathParams, localVarHttpContentType);

            int localVarStatusCode = (int) localVarResponse.StatusCode;
 
            if (localVarStatusCode >= 400)
                throw new ApiException (localVarStatusCode, "Error calling SmsPost: " + localVarResponse.Content, localVarResponse.Content);
            else if (localVarStatusCode == 0)
                throw new ApiException (localVarStatusCode, "Error calling SmsPost: " + localVarResponse.ErrorMessage, localVarResponse.ErrorMessage);

            return new ApiResponse<SMSResponse>(localVarStatusCode,
                localVarResponse.Headers.ToDictionary(x => x.Name, x => x.Value.ToString()),
                (SMSResponse) Configuration.ApiClient.Deserialize(localVarResponse, typeof(SMSResponse)));
            
        }
        
    }
    
}
