using System;
using System.Linq;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace IO.Swagger.Model
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public partial class Balance :  IEquatable<Balance>
    { 
    
        /// <summary>
        /// Initializes a new instance of the <see cref="Balance" /> class.
        /// Initializes a new instance of the <see cref="Balance" />class.
        /// </summary>
        /// <param name="_Balance">The user account balance..</param>

        public Balance(float? _Balance = null)
        {
            this._Balance = _Balance;
            
        }
        
    
        /// <summary>
        /// The user account balance.
        /// </summary>
        /// <value>The user account balance.</value>
        [DataMember(Name="balance", EmitDefaultValue=false)]
        public float? _Balance { get; set; }
    
        /// <summary>
        /// Returns the string presentation of the object
        /// </summary>
        /// <returns>String presentation of the object</returns>
        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.Append("class Balance {\n");
            sb.Append("  _Balance: ").Append(_Balance).Append("\n");
            
            sb.Append("}\n");
            return sb.ToString();
        }
  
        /// <summary>
        /// Returns the JSON string presentation of the object
        /// </summary>
        /// <returns>JSON string presentation of the object</returns>
        public string ToJson()
        {
            return JsonConvert.SerializeObject(this, Formatting.Indented);
        }

        /// <summary>
        /// Returns true if objects are equal
        /// </summary>
        /// <param name="obj">Object to be compared</param>
        /// <returns>Boolean</returns>
        public override bool Equals(object obj)
        {
            // credit: http://stackoverflow.com/a/10454552/677735
            return this.Equals(obj as Balance);
        }

        /// <summary>
        /// Returns true if Balance instances are equal
        /// </summary>
        /// <param name="other">Instance of Balance to be compared</param>
        /// <returns>Boolean</returns>
        public bool Equals(Balance other)
        {
            // credit: http://stackoverflow.com/a/10454552/677735
            if (other == null)
                return false;

            return 
                (
                    this._Balance == other._Balance ||
                    this._Balance != null &&
                    this._Balance.Equals(other._Balance)
                );
        }

        /// <summary>
        /// Gets the hash code
        /// </summary>
        /// <returns>Hash code</returns>
        public override int GetHashCode()
        {
            // credit: http://stackoverflow.com/a/263416/677735
            unchecked // Overflow is fine, just wrap
            {
                int hash = 41;
                // Suitable nullity checks etc, of course :)
                
                if (this._Balance != null)
                    hash = hash * 59 + this._Balance.GetHashCode();
                
                return hash;
            }
        }

    }
}
