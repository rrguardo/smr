using System;
using System.Linq;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace IO.Swagger.Model
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public partial class SMSResponse :  IEquatable<SMSResponse>
    { 
    
        /// <summary>
        /// Initializes a new instance of the <see cref="SMSResponse" /> class.
        /// Initializes a new instance of the <see cref="SMSResponse" />class.
        /// </summary>
        /// <param name="Success">The success key is returned when message was delivered ok to EasySMS system..</param>
        /// <param name="Pid">The processing id pid returned can be used for track the SMS message status..</param>

        public SMSResponse(string Success = null, int? Pid = null)
        {
            this.Success = Success;
            this.Pid = Pid;
            
        }
        
    
        /// <summary>
        /// The success key is returned when message was delivered ok to EasySMS system.
        /// </summary>
        /// <value>The success key is returned when message was delivered ok to EasySMS system.</value>
        [DataMember(Name="success", EmitDefaultValue=false)]
        public string Success { get; set; }
    
        /// <summary>
        /// The processing id pid returned can be used for track the SMS message status.
        /// </summary>
        /// <value>The processing id pid returned can be used for track the SMS message status.</value>
        [DataMember(Name="pid", EmitDefaultValue=false)]
        public int? Pid { get; set; }
    
        /// <summary>
        /// Returns the string presentation of the object
        /// </summary>
        /// <returns>String presentation of the object</returns>
        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.Append("class SMSResponse {\n");
            sb.Append("  Success: ").Append(Success).Append("\n");
            sb.Append("  Pid: ").Append(Pid).Append("\n");
            
            sb.Append("}\n");
            return sb.ToString();
        }
  
        /// <summary>
        /// Returns the JSON string presentation of the object
        /// </summary>
        /// <returns>JSON string presentation of the object</returns>
        public string ToJson()
        {
            return JsonConvert.SerializeObject(this, Formatting.Indented);
        }

        /// <summary>
        /// Returns true if objects are equal
        /// </summary>
        /// <param name="obj">Object to be compared</param>
        /// <returns>Boolean</returns>
        public override bool Equals(object obj)
        {
            // credit: http://stackoverflow.com/a/10454552/677735
            return this.Equals(obj as SMSResponse);
        }

        /// <summary>
        /// Returns true if SMSResponse instances are equal
        /// </summary>
        /// <param name="other">Instance of SMSResponse to be compared</param>
        /// <returns>Boolean</returns>
        public bool Equals(SMSResponse other)
        {
            // credit: http://stackoverflow.com/a/10454552/677735
            if (other == null)
                return false;

            return 
                (
                    this.Success == other.Success ||
                    this.Success != null &&
                    this.Success.Equals(other.Success)
                ) && 
                (
                    this.Pid == other.Pid ||
                    this.Pid != null &&
                    this.Pid.Equals(other.Pid)
                );
        }

        /// <summary>
        /// Gets the hash code
        /// </summary>
        /// <returns>Hash code</returns>
        public override int GetHashCode()
        {
            // credit: http://stackoverflow.com/a/263416/677735
            unchecked // Overflow is fine, just wrap
            {
                int hash = 41;
                // Suitable nullity checks etc, of course :)
                
                if (this.Success != null)
                    hash = hash * 59 + this.Success.GetHashCode();
                
                if (this.Pid != null)
                    hash = hash * 59 + this.Pid.GetHashCode();
                
                return hash;
            }
        }

    }
}
