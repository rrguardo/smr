goog.provide('API.Client.SMSResponse');

/**
 * @record
 */
API.Client.SMSResponse = function() {}

/**
 * The success key is returned when message was delivered ok to EasySMS system.
 * @type {!string}
 * @export
 */
API.Client.SMSResponse.prototype.success;

/**
 * The processing id pid returned can be used for track the SMS message status.
 * @type {!number}
 * @export
 */
API.Client.SMSResponse.prototype.pid;

