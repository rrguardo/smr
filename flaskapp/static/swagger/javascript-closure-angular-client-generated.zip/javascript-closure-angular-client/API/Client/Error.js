goog.provide('API.Client.Error');

/**
 * @record
 */
API.Client.Error = function() {}

/**
 * Error description info.
 * @type {!string}
 * @export
 */
API.Client.Error.prototype.error;

