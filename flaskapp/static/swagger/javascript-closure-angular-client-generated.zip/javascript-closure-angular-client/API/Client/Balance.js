goog.provide('API.Client.Balance');

/**
 * @record
 */
API.Client.Balance = function() {}

/**
 * The user account balance.
 * @type {!number}
 * @export
 */
API.Client.Balance.prototype.balance;

