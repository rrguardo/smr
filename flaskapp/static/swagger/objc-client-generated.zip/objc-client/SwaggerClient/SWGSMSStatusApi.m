#import "SWGSMSStatusApi.h"
#import "SWGQueryParamCollection.h"
#import "SWGSMSStatus.h"
#import "SWGError.h"


@interface SWGSMSStatusApi ()
    @property (readwrite, nonatomic, strong) NSMutableDictionary *defaultHeaders;
@end

@implementation SWGSMSStatusApi

static SWGSMSStatusApi* singletonAPI = nil;

#pragma mark - Initialize methods

- (id) init {
    self = [super init];
    if (self) {
        SWGConfiguration *config = [SWGConfiguration sharedConfig];
        if (config.apiClient == nil) {
            config.apiClient = [[SWGApiClient alloc] init];
        }
        self.apiClient = config.apiClient;
        self.defaultHeaders = [NSMutableDictionary dictionary];
    }
    return self;
}

- (id) initWithApiClient:(SWGApiClient *)apiClient {
    self = [super init];
    if (self) {
        self.apiClient = apiClient;
        self.defaultHeaders = [NSMutableDictionary dictionary];
    }
    return self;
}

#pragma mark -

+(SWGSMSStatusApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key {

    if (singletonAPI == nil) {
        singletonAPI = [[SWGSMSStatusApi alloc] init];
        [singletonAPI addHeader:headerValue forKey:key];
    }
    return singletonAPI;
}

+(SWGSMSStatusApi*) sharedAPI {

    if (singletonAPI == nil) {
        singletonAPI = [[SWGSMSStatusApi alloc] init];
    }
    return singletonAPI;
}

-(void) addHeader:(NSString*)value forKey:(NSString*)key {
    [self.defaultHeaders setValue:value forKey:key];
}

-(void) setHeaderValue:(NSString*) value
           forKey:(NSString*)key {
    [self.defaultHeaders setValue:value forKey:key];
}

-(unsigned long) requestQueueSize {
    return [SWGApiClient requestQueueSize];
}

#pragma mark - Api Methods

///
/// Verify SMS sent status
/// Use this API endpoint to verify SMS sent status.
///  @param userId The user account id, located at user panel.
///
///  @param authToken The user authentication token, located at user panel.
///
///  @param pid The processing id pid returned when you sent the sms.
///
///  @returns SWGSMSStatus*
///
-(NSNumber*) statusPostWithUserId: (NSNumber*) userId
    authToken: (NSString*) authToken
    pid: (NSNumber*) pid
    completionHandler: (void (^)(SWGSMSStatus* output, NSError* error)) handler {

    
    // verify the required parameter 'userId' is set
    if (userId == nil) {
        [NSException raise:@"Invalid parameter" format:@"Missing the required parameter `userId` when calling `statusPost`"];
    }
    
    // verify the required parameter 'authToken' is set
    if (authToken == nil) {
        [NSException raise:@"Invalid parameter" format:@"Missing the required parameter `authToken` when calling `statusPost`"];
    }
    
    // verify the required parameter 'pid' is set
    if (pid == nil) {
        [NSException raise:@"Invalid parameter" format:@"Missing the required parameter `pid` when calling `statusPost`"];
    }
    

    NSMutableString* resourcePath = [NSMutableString stringWithFormat:@"/status"];

    // remove format in URL if needed
    if ([resourcePath rangeOfString:@".{format}"].location != NSNotFound) {
        [resourcePath replaceCharactersInRange: [resourcePath rangeOfString:@".{format}"] withString:@".json"];
    }

    NSMutableDictionary *pathParams = [[NSMutableDictionary alloc] init];
    

    NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    
    NSMutableDictionary* headerParams = [NSMutableDictionary dictionaryWithDictionary:self.defaultHeaders];

    

    // HTTP header `Accept`
    headerParams[@"Accept"] = [SWGApiClient selectHeaderAccept:@[@"application/json"]];
    if ([headerParams[@"Accept"] length] == 0) {
        [headerParams removeObjectForKey:@"Accept"];
    }

    // response content type
    NSString *responseContentType;
    if ([headerParams objectForKey:@"Accept"]) {
        responseContentType = [headerParams[@"Accept"] componentsSeparatedByString:@", "][0];
    }
    else {
        responseContentType = @"";
    }

    // request content type
    NSString *requestContentType = [SWGApiClient selectHeaderContentType:@[@"application/x-www-form-urlencoded"]];

    // Authentication setting
    NSArray *authSettings = @[];

    id bodyParam = nil;
    NSMutableDictionary *formParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary *localVarFiles = [[NSMutableDictionary alloc] init];
    
    
    
    if (userId) {
        formParams[@"user_id"] = userId;
    }
    
    
    
    if (authToken) {
        formParams[@"auth_token"] = authToken;
    }
    
    
    
    if (pid) {
        formParams[@"pid"] = pid;
    }
    
    
    

    
    return [self.apiClient requestWithPath: resourcePath
                                    method: @"POST"
                                pathParams: pathParams
                               queryParams: queryParams
                                formParams: formParams
                                     files: localVarFiles
                                      body: bodyParam
                              headerParams: headerParams
                              authSettings: authSettings
                        requestContentType: requestContentType
                       responseContentType: responseContentType
                              responseType: @"SWGSMSStatus*"
                           completionBlock: ^(id data, NSError *error) {
                               handler((SWGSMSStatus*)data, error);
                           }
          ];
}



@end
