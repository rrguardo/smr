#import "SWGSendSMSApi.h"
#import "SWGQueryParamCollection.h"
#import "SWGSMSResponse.h"
#import "SWGError.h"


@interface SWGSendSMSApi ()
    @property (readwrite, nonatomic, strong) NSMutableDictionary *defaultHeaders;
@end

@implementation SWGSendSMSApi

static SWGSendSMSApi* singletonAPI = nil;

#pragma mark - Initialize methods

- (id) init {
    self = [super init];
    if (self) {
        SWGConfiguration *config = [SWGConfiguration sharedConfig];
        if (config.apiClient == nil) {
            config.apiClient = [[SWGApiClient alloc] init];
        }
        self.apiClient = config.apiClient;
        self.defaultHeaders = [NSMutableDictionary dictionary];
    }
    return self;
}

- (id) initWithApiClient:(SWGApiClient *)apiClient {
    self = [super init];
    if (self) {
        self.apiClient = apiClient;
        self.defaultHeaders = [NSMutableDictionary dictionary];
    }
    return self;
}

#pragma mark -

+(SWGSendSMSApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key {

    if (singletonAPI == nil) {
        singletonAPI = [[SWGSendSMSApi alloc] init];
        [singletonAPI addHeader:headerValue forKey:key];
    }
    return singletonAPI;
}

+(SWGSendSMSApi*) sharedAPI {

    if (singletonAPI == nil) {
        singletonAPI = [[SWGSendSMSApi alloc] init];
    }
    return singletonAPI;
}

-(void) addHeader:(NSString*)value forKey:(NSString*)key {
    [self.defaultHeaders setValue:value forKey:key];
}

-(void) setHeaderValue:(NSString*) value
           forKey:(NSString*)key {
    [self.defaultHeaders setValue:value forKey:key];
}

-(unsigned long) requestQueueSize {
    return [SWGApiClient requestQueueSize];
}

#pragma mark - Api Methods

///
/// Send SMS text message
/// Use this API endpoint to send SMS text messages.
///  @param userId The user account id, located at user panel.
///
///  @param authToken The user authentication token, located at user panel.
///
///  @param to The phone number where send the SMS.
///
///  @param body The SMS text message to send.
///
///  @returns SWGSMSResponse*
///
-(NSNumber*) smsPostWithUserId: (NSNumber*) userId
    authToken: (NSString*) authToken
    to: (NSString*) to
    body: (NSString*) body
    completionHandler: (void (^)(SWGSMSResponse* output, NSError* error)) handler {

    
    // verify the required parameter 'userId' is set
    if (userId == nil) {
        [NSException raise:@"Invalid parameter" format:@"Missing the required parameter `userId` when calling `smsPost`"];
    }
    
    // verify the required parameter 'authToken' is set
    if (authToken == nil) {
        [NSException raise:@"Invalid parameter" format:@"Missing the required parameter `authToken` when calling `smsPost`"];
    }
    
    // verify the required parameter 'to' is set
    if (to == nil) {
        [NSException raise:@"Invalid parameter" format:@"Missing the required parameter `to` when calling `smsPost`"];
    }
    
    // verify the required parameter 'body' is set
    if (body == nil) {
        [NSException raise:@"Invalid parameter" format:@"Missing the required parameter `body` when calling `smsPost`"];
    }
    

    NSMutableString* resourcePath = [NSMutableString stringWithFormat:@"/sms"];

    // remove format in URL if needed
    if ([resourcePath rangeOfString:@".{format}"].location != NSNotFound) {
        [resourcePath replaceCharactersInRange: [resourcePath rangeOfString:@".{format}"] withString:@".json"];
    }

    NSMutableDictionary *pathParams = [[NSMutableDictionary alloc] init];
    

    NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    
    NSMutableDictionary* headerParams = [NSMutableDictionary dictionaryWithDictionary:self.defaultHeaders];

    

    // HTTP header `Accept`
    headerParams[@"Accept"] = [SWGApiClient selectHeaderAccept:@[@"application/json"]];
    if ([headerParams[@"Accept"] length] == 0) {
        [headerParams removeObjectForKey:@"Accept"];
    }

    // response content type
    NSString *responseContentType;
    if ([headerParams objectForKey:@"Accept"]) {
        responseContentType = [headerParams[@"Accept"] componentsSeparatedByString:@", "][0];
    }
    else {
        responseContentType = @"";
    }

    // request content type
    NSString *requestContentType = [SWGApiClient selectHeaderContentType:@[@"application/x-www-form-urlencoded"]];

    // Authentication setting
    NSArray *authSettings = @[];

    id bodyParam = nil;
    NSMutableDictionary *formParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary *localVarFiles = [[NSMutableDictionary alloc] init];
    
    
    
    if (userId) {
        formParams[@"user_id"] = userId;
    }
    
    
    
    if (authToken) {
        formParams[@"auth_token"] = authToken;
    }
    
    
    
    if (to) {
        formParams[@"to"] = to;
    }
    
    
    
    if (body) {
        formParams[@"body"] = body;
    }
    
    
    

    
    return [self.apiClient requestWithPath: resourcePath
                                    method: @"POST"
                                pathParams: pathParams
                               queryParams: queryParams
                                formParams: formParams
                                     files: localVarFiles
                                      body: bodyParam
                              headerParams: headerParams
                              authSettings: authSettings
                        requestContentType: requestContentType
                       responseContentType: responseContentType
                              responseType: @"SWGSMSResponse*"
                           completionBlock: ^(id data, NSError *error) {
                               handler((SWGSMSResponse*)data, error);
                           }
          ];
}



@end
