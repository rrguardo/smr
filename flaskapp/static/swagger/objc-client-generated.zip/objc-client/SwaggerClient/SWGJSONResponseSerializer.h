#import <Foundation/Foundation.h>
#import <AFNetworking/AFURLResponseSerialization.h>

@interface SWGJSONResponseSerializer : AFJSONResponseSerializer

@end
