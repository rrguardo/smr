package io.swagger.client.model




case class Balance (
  /* The user account balance. */
  balance: Float)
  
