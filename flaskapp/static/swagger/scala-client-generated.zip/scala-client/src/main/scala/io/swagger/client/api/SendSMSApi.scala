package io.swagger.client.api

import io.swagger.client.model.SMSResponse
import io.swagger.client.model.Error
import io.swagger.client.ApiInvoker
import io.swagger.client.ApiException

import com.sun.jersey.multipart.FormDataMultiPart
import com.sun.jersey.multipart.file.FileDataBodyPart

import javax.ws.rs.core.MediaType

import java.io.File
import java.util.Date

import scala.collection.mutable.HashMap

class SendSMSApi(val defBasePath: String = "https://api.4simple.org/",
                        defApiInvoker: ApiInvoker = ApiInvoker) {
  var basePath = defBasePath
  var apiInvoker = defApiInvoker

  def addHeader(key: String, value: String) = apiInvoker.defaultHeaders += key -> value 

  
  /**
   * Send SMS text message
   * Use this API endpoint to send SMS text messages.
   * @param userId The user account id, located at user panel.
   * @param authToken The user authentication token, located at user panel.
   * @param to The phone number where send the SMS.
   * @param body The SMS text message to send.
   * @return SMSResponse
   */
  def smsPost (userId: Integer, authToken: String, to: String, body: String) : Option[SMSResponse] = {
    // create path and map variables
    val path = "/sms".replaceAll("\\{format\\}","json")

    val contentTypes = List("application/x-www-form-urlencoded", "application/json")
    val contentType = contentTypes(0)

    // query params
    val queryParams = new HashMap[String, String]
    val headerParams = new HashMap[String, String]
    val formParams = new HashMap[String, String]

    

    
    
    

    var postBody: AnyRef = null

    if(contentType.startsWith("multipart/form-data")) {
      val mp = new FormDataMultiPart()
      
      mp.field("user_id", userId.toString(), MediaType.MULTIPART_FORM_DATA_TYPE)
      
      mp.field("auth_token", authToken.toString(), MediaType.MULTIPART_FORM_DATA_TYPE)
      
      mp.field("to", to.toString(), MediaType.MULTIPART_FORM_DATA_TYPE)
      
      mp.field("body", body.toString(), MediaType.MULTIPART_FORM_DATA_TYPE)
      
      postBody = mp
    }
    else {
      formParams += "user_id" -> userId.toString()
      formParams += "auth_token" -> authToken.toString()
      formParams += "to" -> to.toString()
      formParams += "body" -> body.toString()
      
    }

    try {
      apiInvoker.invokeApi(basePath, path, "POST", queryParams.toMap, formParams.toMap, postBody, headerParams.toMap, contentType) match {
        case s: String =>
           Some(ApiInvoker.deserialize(s, "", classOf[SMSResponse]).asInstanceOf[SMSResponse])
         
        case _ => None
      }
    } catch {
      case ex: ApiException if ex.code == 404 => None
      case ex: ApiException => throw ex
    }
  }
  
}
