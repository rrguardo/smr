package io.swagger.client.model




case class Error (
  /* Error description info. */
  error: String)
  
