part of api;


@Entity()
class SMSStatus {
  /* The SMS processing status info.\nPossible status values are:\n  - queued When the sms is in the processing queue waiting to be delivered.\n  - success-delivered The sms was delivered successful.\n  - failed The sms delivery fails. */
  String status = null;
  
  
  SMSStatus();

  @override
  String toString()  {
    return 'SMSStatus[status=$status, ]';
  }

}

