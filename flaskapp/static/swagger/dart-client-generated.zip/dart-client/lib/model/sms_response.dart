part of api;


@Entity()
class SMSResponse {
  /* The success key is returned when message was delivered ok to EasySMS system. */
  String success = null;
  
  /* The processing id pid returned can be used for track the SMS message status. */
  int pid = null;
  
  
  SMSResponse();

  @override
  String toString()  {
    return 'SMSResponse[success=$success, pid=$pid, ]';
  }

}

