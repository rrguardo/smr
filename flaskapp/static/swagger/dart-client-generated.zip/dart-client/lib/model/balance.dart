part of api;


@Entity()
class Balance {
  /* The user account balance. */
  num balance = null;
  
  
  Balance();

  @override
  String toString()  {
    return 'Balance[balance=$balance, ]';
  }

}

