part of api;


@Entity()
class Error {
  /* Error description info. */
  String error = null;
  
  
  Error();

  @override
  String toString()  {
    return 'Error[error=$error, ]';
  }

}

