part of api;


class SMSStatusApi {
  String basePath = "https://api.4simple.org/";
  ApiClient apiClient = ApiClient.defaultApiClient;

  SMSStatusApi([ApiClient apiClient]) {
    if (apiClient != null) {
      this.apiClient = apiClient;
    }
  }

  
  /// Verify SMS sent status
  ///
  /// Use this API endpoint to verify SMS sent status.
  Future<SMSStatus> statusPost(int userId, String authToken, int pid) {
    Object postBody = null;
    

    // create path and map variables
    String path = "/status".replaceAll("{format}","json");

    // query params
    Map<String, String> queryParams = {};
    Map<String, String> headerParams = {};
    Map<String, String> formParams = {};
    
    

    List<String> contentTypes = ["application/x-www-form-urlencoded"];

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";
    List<String> authNames = [];

    if(contentType.startsWith("multipart/form-data")) {
      bool hasFields = false;
      MultipartRequest mp = new MultipartRequest(null, null);
      
      if (userId != null) {
        hasFields = true;
        mp.fields['user_id'] = apiClient.parameterToString(userId);
      }
      
      if (authToken != null) {
        hasFields = true;
        mp.fields['auth_token'] = apiClient.parameterToString(authToken);
      }
      
      if (pid != null) {
        hasFields = true;
        mp.fields['pid'] = apiClient.parameterToString(pid);
      }
      
      if(hasFields)
        postBody = mp;
    }
    else {
      if (userId != null)
        formParams['user_id'] = apiClient.parameterToString(userId);
      if (authToken != null)
        formParams['auth_token'] = apiClient.parameterToString(authToken);
      if (pid != null)
        formParams['pid'] = apiClient.parameterToString(pid);
      
    }

    return apiClient.invokeAPI(basePath, path, 'POST', queryParams, postBody, headerParams, formParams, contentType, authNames).then((response) {
      if(response.statusCode >= 400) {
        throw new ApiException(response.statusCode, response.body);
      }
      else if(response.body != null){
        return ApiClient.deserialize(response.body, SMSStatus);
      }
      else {
        return null;
      }
    });
  }
  
}
