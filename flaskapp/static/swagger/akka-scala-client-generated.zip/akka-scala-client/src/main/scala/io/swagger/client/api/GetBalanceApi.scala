package io.swagger.client.api

import io.swagger.client.model.Error
import io.swagger.client.model.Balance
import io.swagger.client.core._
import io.swagger.client.core.CollectionFormats._
import io.swagger.client.core.ApiKeyLocations._

object GetBalanceApi {

  /**
   * Use this API endpoint to get account balance.
   * 
   * Expected answers:
   *   code 200 : Balance (An object with balance information or error info.)
   *   code 0 : Error (Error processing request)
   * 
   * @param userId The user account id, located at user panel.
   * @param authToken The user authentication token, located at user panel.
   */
  def balancePost(userId: Int, authToken: String): ApiRequest[Balance] =
    ApiRequest[Balance](ApiMethods.POST, "https://api.4simple.org/", "/balance", "application/x-www-form-urlencoded")
      .withFormParam("user_id", userId)
      .withFormParam("auth_token", authToken)
      .withSuccessResponse[Balance](200)
      .withDefaultErrorResponse[Error]
      


}

