package io.swagger.client.api

import io.swagger.client.model.SMSResponse
import io.swagger.client.model.Error
import io.swagger.client.core._
import io.swagger.client.core.CollectionFormats._
import io.swagger.client.core.ApiKeyLocations._

object SendSMSApi {

  /**
   * Use this API endpoint to send SMS text messages.
   * 
   * Expected answers:
   *   code 200 : SMSResponse (An object with status and processing id or an error code)
   *   code 0 : Error (Error processing request)
   * 
   * @param userId The user account id, located at user panel.
   * @param authToken The user authentication token, located at user panel.
   * @param to The phone number where send the SMS.
   * @param body The SMS text message to send.
   */
  def smsPost(userId: Int, authToken: String, to: String, body: String): ApiRequest[SMSResponse] =
    ApiRequest[SMSResponse](ApiMethods.POST, "https://api.4simple.org/", "/sms", "application/x-www-form-urlencoded")
      .withFormParam("user_id", userId)
      .withFormParam("auth_token", authToken)
      .withFormParam("to", to)
      .withFormParam("body", body)
      .withSuccessResponse[SMSResponse](200)
      .withDefaultErrorResponse[Error]
      


}

