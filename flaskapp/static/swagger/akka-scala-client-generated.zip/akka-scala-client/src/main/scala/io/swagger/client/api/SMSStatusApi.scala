package io.swagger.client.api

import io.swagger.client.model.SMS_Status
import io.swagger.client.model.Error
import io.swagger.client.core._
import io.swagger.client.core.CollectionFormats._
import io.swagger.client.core.ApiKeyLocations._

object SMSStatusApi {

  /**
   * Use this API endpoint to verify SMS sent status.
   * 
   * Expected answers:
   *   code 200 : SMS_Status (An object with balance amount or an error info.)
   *   code 0 : Error (Error processing request)
   * 
   * @param userId The user account id, located at user panel.
   * @param authToken The user authentication token, located at user panel.
   * @param pid The processing id pid returned when you sent the sms.
   */
  def statusPost(userId: Int, authToken: String, pid: Int): ApiRequest[SMS_Status] =
    ApiRequest[SMS_Status](ApiMethods.POST, "https://api.4simple.org/", "/status", "application/x-www-form-urlencoded")
      .withFormParam("user_id", userId)
      .withFormParam("auth_token", authToken)
      .withFormParam("pid", pid)
      .withSuccessResponse[SMS_Status](200)
      .withDefaultErrorResponse[Error]
      


}

