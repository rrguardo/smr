package io.swagger.client.model

import io.swagger.client.core.ApiModel
import org.joda.time.DateTime


case class Error (
  /* Error description info. */
  error: Option[String])
   extends ApiModel


