#ifndef SamiGetBalanceApi_H_
#define SamiGetBalanceApi_H_

#include <FNet.h>
#include "SamiApiClient.h"
#include "SamiError.h"

using Tizen::Base::Integer;
#include "SamiError.h"
#include "SamiBalance.h"
using Tizen::Base::String;

using namespace Tizen::Net::Http;

namespace Swagger {

class SamiGetBalanceApi {
public:
  SamiGetBalanceApi();
  virtual ~SamiGetBalanceApi();

  
  SamiBalance* 
  balancePostWithCompletion(Integer* userId, String* authToken, void (* handler)(SamiBalance*, SamiError*));
  
  static String getBasePath() {
    return L"https://api.4simple.org/";
  }

private:
  SamiApiClient* client;
};


} /* namespace Swagger */

#endif /* SamiGetBalanceApi_H_ */
