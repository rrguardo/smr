#ifndef ModelFactory_H_
#define ModelFactory_H_

#include "SamiObject.h"

#include "SamiBalance.h"
#include "SamiError.h"
#include "SamiSMSResponse.h"
#include "SamiSMS_Status.h"

namespace Swagger {
  void*
  create(String type) {
    if(type.Equals(L"SamiBalance", true)) {
      return new SamiBalance();
    }
    if(type.Equals(L"SamiError", true)) {
      return new SamiError();
    }
    if(type.Equals(L"SamiSMSResponse", true)) {
      return new SamiSMSResponse();
    }
    if(type.Equals(L"SamiSMS_Status", true)) {
      return new SamiSMS_Status();
    }
    
    if(type.Equals(L"String", true)) {
      return new String();
    }
    if(type.Equals(L"Integer", true)) {
      return new Integer();
    }
    if(type.Equals(L"Long", true)) {
      return new Long();
    }
    if(type.Equals(L"DateTime", true)) {
      return new DateTime();
    }
    return null;
  }
} /* namespace Swagger */

#endif /* ModelFactory_H_ */
