/*
 * SamiBalance.h
 * 
 * 
 */

#ifndef SamiBalance_H_
#define SamiBalance_H_

#include <FApp.h>
#include <FBase.h>
#include <FSystem.h>
#include <FWebJson.h>
#include "SamiHelpers.h"
#include "SamiObject.h"

using namespace Tizen::Web::Json;


using Tizen::Base::Float;


namespace Swagger {

class SamiBalance: public SamiObject {
public:
    SamiBalance();
    SamiBalance(String* json);
    virtual ~SamiBalance();

    void init();

    void cleanup();

    String asJson ();

    JsonObject* asJsonObject();

    void fromJsonObject(IJsonValue* json);

    SamiBalance* fromJson(String* obj);

    
    Float* getPBalance();
    void setPBalance(Float* pBalance);
    

private:
    Float* pBalance;
    
};

} /* namespace Swagger */

#endif /* SamiBalance_H_ */
