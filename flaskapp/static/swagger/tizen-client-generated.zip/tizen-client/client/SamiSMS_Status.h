/*
 * SamiSMS_Status.h
 * 
 * 
 */

#ifndef SamiSMS_Status_H_
#define SamiSMS_Status_H_

#include <FApp.h>
#include <FBase.h>
#include <FSystem.h>
#include <FWebJson.h>
#include "SamiHelpers.h"
#include "SamiObject.h"

using namespace Tizen::Web::Json;


using Tizen::Base::String;


namespace Swagger {

class SamiSMS_Status: public SamiObject {
public:
    SamiSMS_Status();
    SamiSMS_Status(String* json);
    virtual ~SamiSMS_Status();

    void init();

    void cleanup();

    String asJson ();

    JsonObject* asJsonObject();

    void fromJsonObject(IJsonValue* json);

    SamiSMS_Status* fromJson(String* obj);

    
    String* getPStatus();
    void setPStatus(String* pStatus);
    

private:
    String* pStatus;
    
};

} /* namespace Swagger */

#endif /* SamiSMS_Status_H_ */
