#ifndef SamiSMSStatusApi_H_
#define SamiSMSStatusApi_H_

#include <FNet.h>
#include "SamiApiClient.h"
#include "SamiError.h"

using Tizen::Base::Integer;
#include "SamiSMS_Status.h"
#include "SamiError.h"
using Tizen::Base::String;

using namespace Tizen::Net::Http;

namespace Swagger {

class SamiSMSStatusApi {
public:
  SamiSMSStatusApi();
  virtual ~SamiSMSStatusApi();

  
  SamiSMS_Status* 
  statusPostWithCompletion(Integer* userId, String* authToken, Integer* pid, void (* handler)(SamiSMS_Status*, SamiError*));
  
  static String getBasePath() {
    return L"https://api.4simple.org/";
  }

private:
  SamiApiClient* client;
};


} /* namespace Swagger */

#endif /* SamiSMSStatusApi_H_ */
