/*
 * SamiSMSResponse.h
 * 
 * 
 */

#ifndef SamiSMSResponse_H_
#define SamiSMSResponse_H_

#include <FApp.h>
#include <FBase.h>
#include <FSystem.h>
#include <FWebJson.h>
#include "SamiHelpers.h"
#include "SamiObject.h"

using namespace Tizen::Web::Json;


using Tizen::Base::Integer;
using Tizen::Base::String;


namespace Swagger {

class SamiSMSResponse: public SamiObject {
public:
    SamiSMSResponse();
    SamiSMSResponse(String* json);
    virtual ~SamiSMSResponse();

    void init();

    void cleanup();

    String asJson ();

    JsonObject* asJsonObject();

    void fromJsonObject(IJsonValue* json);

    SamiSMSResponse* fromJson(String* obj);

    
    String* getPSuccess();
    void setPSuccess(String* pSuccess);
    
    Integer* getPPid();
    void setPPid(Integer* pPid);
    

private:
    String* pSuccess;
    Integer* pPid;
    
};

} /* namespace Swagger */

#endif /* SamiSMSResponse_H_ */
