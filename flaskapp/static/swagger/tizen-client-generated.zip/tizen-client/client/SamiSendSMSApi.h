#ifndef SamiSendSMSApi_H_
#define SamiSendSMSApi_H_

#include <FNet.h>
#include "SamiApiClient.h"
#include "SamiError.h"

using Tizen::Base::Integer;
#include "SamiSMSResponse.h"
#include "SamiError.h"
using Tizen::Base::String;

using namespace Tizen::Net::Http;

namespace Swagger {

class SamiSendSMSApi {
public:
  SamiSendSMSApi();
  virtual ~SamiSendSMSApi();

  
  SamiSMSResponse* 
  smsPostWithCompletion(Integer* userId, String* authToken, String* to, String* body, void (* handler)(SamiSMSResponse*, SamiError*));
  
  static String getBasePath() {
    return L"https://api.4simple.org/";
  }

private:
  SamiApiClient* client;
};


} /* namespace Swagger */

#endif /* SamiSendSMSApi_H_ */
