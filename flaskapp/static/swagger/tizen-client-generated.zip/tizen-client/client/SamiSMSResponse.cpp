
#include "SamiSMSResponse.h"
#include <FLocales.h>

using namespace Tizen::Base;
using namespace Tizen::System;
using namespace Tizen::Base::Utility;
using namespace Tizen::Base::Collection;
using namespace Tizen::Web::Json;
using namespace Tizen::Locales;


namespace Swagger {

SamiSMSResponse::SamiSMSResponse() {
    init();
}

SamiSMSResponse::~SamiSMSResponse() {
    this->cleanup();
}

void
SamiSMSResponse::init() {
    pSuccess = null;
    pPid = null;
    
}

void
SamiSMSResponse::cleanup() {
    if(pSuccess != null) {
        
        delete pSuccess;
        pSuccess = null;
    }
    if(pPid != null) {
        
        delete pPid;
        pPid = null;
    }
    
}


SamiSMSResponse*
SamiSMSResponse::fromJson(String* json) {
    this->cleanup();
    String str(json->GetPointer());
    int length = str.GetLength();

    ByteBuffer buffer;
    buffer.Construct(length);

    for (int i = 0; i < length; ++i) {
       byte b = str[i];
       buffer.SetByte(b);
    }

    IJsonValue* pJson = JsonParser::ParseN(buffer);
    fromJsonObject(pJson);
    if (pJson->GetType() == JSON_TYPE_OBJECT) {
       JsonObject* pObject = static_cast< JsonObject* >(pJson);
       pObject->RemoveAll(true);
    }
    else if (pJson->GetType() == JSON_TYPE_ARRAY) {
       JsonArray* pArray = static_cast< JsonArray* >(pJson);
       pArray->RemoveAll(true);
    }
    delete pJson;
    return this;
}


void
SamiSMSResponse::fromJsonObject(IJsonValue* pJson) {
    JsonObject* pJsonObject = static_cast< JsonObject* >(pJson);

    if(pJsonObject != null) {
        JsonString* pSuccessKey = new JsonString(L"success");
        IJsonValue* pSuccessVal = null;
        pJsonObject->GetValue(pSuccessKey, pSuccessVal);
        if(pSuccessVal != null) {
            
            pSuccess = new String();
            jsonToValue(pSuccess, pSuccessVal, L"String", L"String");
        }
        delete pSuccessKey;
        JsonString* pPidKey = new JsonString(L"pid");
        IJsonValue* pPidVal = null;
        pJsonObject->GetValue(pPidKey, pPidVal);
        if(pPidVal != null) {
            
            pPid = new Integer();
            jsonToValue(pPid, pPidVal, L"Integer", L"Integer");
        }
        delete pPidKey;
        
    }
}

SamiSMSResponse::SamiSMSResponse(String* json) {
    init();
    String str(json->GetPointer());
    int length = str.GetLength();

    ByteBuffer buffer;
    buffer.Construct(length);

    for (int i = 0; i < length; ++i) {
       byte b = str[i];
       buffer.SetByte(b);
    }

    IJsonValue* pJson = JsonParser::ParseN(buffer);
    fromJsonObject(pJson);
    if (pJson->GetType() == JSON_TYPE_OBJECT) {
       JsonObject* pObject = static_cast< JsonObject* >(pJson);
       pObject->RemoveAll(true);
    }
    else if (pJson->GetType() == JSON_TYPE_ARRAY) {
       JsonArray* pArray = static_cast< JsonArray* >(pJson);
       pArray->RemoveAll(true);
    }
    delete pJson;
}

String
SamiSMSResponse::asJson ()
{
    JsonObject* pJsonObject = asJsonObject();

    char *pComposeBuf = new char[256];
    JsonWriter::Compose(pJsonObject, pComposeBuf, 256);
    String s = String(pComposeBuf);

    delete pComposeBuf;
    pJsonObject->RemoveAll(true);
    delete pJsonObject;

    return s;
}

JsonObject*
SamiSMSResponse::asJsonObject() {
    JsonObject *pJsonObject = new JsonObject();
    pJsonObject->Construct();

    
    JsonString *pSuccessKey = new JsonString(L"success");
    pJsonObject->Add(pSuccessKey, toJson(getPSuccess(), "String", ""));

    
    JsonString *pPidKey = new JsonString(L"pid");
    pJsonObject->Add(pPidKey, toJson(getPPid(), "Integer", ""));

    
    return pJsonObject;
}

String*
SamiSMSResponse::getPSuccess() {
    return pSuccess;
}
void
SamiSMSResponse::setPSuccess(String* pSuccess) {
    this->pSuccess = pSuccess;
}

Integer*
SamiSMSResponse::getPPid() {
    return pPid;
}
void
SamiSMSResponse::setPPid(Integer* pPid) {
    this->pPid = pPid;
}



} /* namespace Swagger */

