package io.swagger.client.model;


import io.swagger.annotations.*;
import com.google.gson.annotations.SerializedName;


@ApiModel(description = "")
public class Balance  {
  
  @SerializedName("balance")
  private Float balance = null;

  
  /**
   * The user account balance.
   **/
  @ApiModelProperty(value = "The user account balance.")
  public Float getBalance() {
    return balance;
  }
  public void setBalance(Float balance) {
    this.balance = balance;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Balance {\n");
    
    sb.append("  balance: ").append(balance).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
