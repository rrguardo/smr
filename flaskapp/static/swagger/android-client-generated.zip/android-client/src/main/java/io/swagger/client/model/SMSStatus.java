package io.swagger.client.model;


import io.swagger.annotations.*;
import com.google.gson.annotations.SerializedName;


@ApiModel(description = "")
public class SMSStatus  {
  
  @SerializedName("status")
  private String status = null;

  
  /**
   * The SMS processing status info.\nPossible status values are:\n  - queued When the sms is in the processing queue waiting to be delivered.\n  - success-delivered The sms was delivered successful.\n  - failed The sms delivery fails.
   **/
  @ApiModelProperty(value = "The SMS processing status info.\nPossible status values are:\n  - queued When the sms is in the processing queue waiting to be delivered.\n  - success-delivered The sms was delivered successful.\n  - failed The sms delivery fails.")
  public String getStatus() {
    return status;
  }
  public void setStatus(String status) {
    this.status = status;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class SMSStatus {\n");
    
    sb.append("  status: ").append(status).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
