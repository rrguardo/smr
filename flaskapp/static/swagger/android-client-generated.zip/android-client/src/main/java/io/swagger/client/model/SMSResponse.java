package io.swagger.client.model;


import io.swagger.annotations.*;
import com.google.gson.annotations.SerializedName;


@ApiModel(description = "")
public class SMSResponse  {
  
  @SerializedName("success")
  private String success = null;
  @SerializedName("pid")
  private Integer pid = null;

  
  /**
   * The success key is returned when message was delivered ok to EasySMS system.
   **/
  @ApiModelProperty(value = "The success key is returned when message was delivered ok to EasySMS system.")
  public String getSuccess() {
    return success;
  }
  public void setSuccess(String success) {
    this.success = success;
  }

  
  /**
   * The processing id pid returned can be used for track the SMS message status.
   **/
  @ApiModelProperty(value = "The processing id pid returned can be used for track the SMS message status.")
  public Integer getPid() {
    return pid;
  }
  public void setPid(Integer pid) {
    this.pid = pid;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class SMSResponse {\n");
    
    sb.append("  success: ").append(success).append("\n");
    sb.append("  pid: ").append(pid).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
