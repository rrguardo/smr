package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;
import io.swagger.client.Pair;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Error;
import io.swagger.client.model.Balance;

import org.apache.http.entity.mime.MultipartEntityBuilder;

import java.util.Map;
import java.util.HashMap;
import java.io.File;

public class GetBalanceApi {
  String basePath = "https://api.4simple.org/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public void addHeader(String key, String value) {
    getInvoker().addDefaultHeader(key, value);
  }

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * Get account balance
   * Use this API endpoint to get account balance.
   * @param userId The user account id, located at user panel.
   * @param authToken The user authentication token, located at user panel.
   * @return Balance
   */
  public Balance  balancePost (Integer userId, String authToken) throws ApiException {
    Object localVarPostBody = null;
    
    // verify the required parameter 'userId' is set
    if (userId == null) {
       throw new ApiException(400, "Missing the required parameter 'userId' when calling balancePost");
    }
    
    // verify the required parameter 'authToken' is set
    if (authToken == null) {
       throw new ApiException(400, "Missing the required parameter 'authToken' when calling balancePost");
    }
    

    // create path and map variables
    String localVarPath = "/balance".replaceAll("\\{format\\}","json");

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    // header params
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    // form params
    Map<String, String> localVarFormParams = new HashMap<String, String>();

    

    

    String[] localVarContentTypes = {
      "application/x-www-form-urlencoded"
    };
    String localVarContentType = localVarContentTypes.length > 0 ? localVarContentTypes[0] : "application/json";

    if (localVarContentType.startsWith("multipart/form-data")) {
      // file uploading
      MultipartEntityBuilder localVarBuilder = MultipartEntityBuilder.create();
      
      if (userId != null) {
        localVarBuilder.addTextBody("user_id", ApiInvoker.parameterToString(userId), ApiInvoker.TEXT_PLAIN_UTF8);
      }
      
      if (authToken != null) {
        localVarBuilder.addTextBody("auth_token", ApiInvoker.parameterToString(authToken), ApiInvoker.TEXT_PLAIN_UTF8);
      }
      

      localVarPostBody = localVarBuilder.build();
    } else {
      // normal form params
      localVarFormParams.put("user_id", ApiInvoker.parameterToString(userId));
      localVarFormParams.put("auth_token", ApiInvoker.parameterToString(authToken));
      
    }

    try {
      String localVarResponse = apiInvoker.invokeAPI(basePath, localVarPath, "POST", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarContentType);
      if(localVarResponse != null){
        return (Balance) ApiInvoker.deserialize(localVarResponse, "", Balance.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}
