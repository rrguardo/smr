(ns easy-sms-api.api.send-sms
  (:require [easy-sms-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn sms-post-with-http-info
  "Send SMS text message
  Use this API endpoint to send SMS text messages."
  [user-id auth-token to body ]
  (call-api "/sms" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {"user_id" user-id "auth_token" auth-token "to" to "body" body }
             :content-types ["application/x-www-form-urlencoded"]
             :accepts       ["application/json"]
             :auth-names    []}))

(defn sms-post
  "Send SMS text message
  Use this API endpoint to send SMS text messages."
  [user-id auth-token to body ]
  (:data (sms-post-with-http-info user-id auth-token to body)))
