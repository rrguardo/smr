(ns easy-sms-api.api.get-balance
  (:require [easy-sms-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn balance-post-with-http-info
  "Get account balance
  Use this API endpoint to get account balance."
  [user-id auth-token ]
  (call-api "/balance" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {"user_id" user-id "auth_token" auth-token }
             :content-types ["application/x-www-form-urlencoded"]
             :accepts       ["application/json"]
             :auth-names    []}))

(defn balance-post
  "Get account balance
  Use this API endpoint to get account balance."
  [user-id auth-token ]
  (:data (balance-post-with-http-info user-id auth-token)))
