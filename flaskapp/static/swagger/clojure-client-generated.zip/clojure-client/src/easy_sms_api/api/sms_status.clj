(ns easy-sms-api.api.sms-status
  (:require [easy-sms-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn status-post-with-http-info
  "Verify SMS sent status
  Use this API endpoint to verify SMS sent status."
  [user-id auth-token pid ]
  (call-api "/status" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {"user_id" user-id "auth_token" auth-token "pid" pid }
             :content-types ["application/x-www-form-urlencoded"]
             :accepts       ["application/json"]
             :auth-names    []}))

(defn status-post
  "Verify SMS sent status
  Use this API endpoint to verify SMS sent status."
  [user-id auth-token pid ]
  (:data (status-post-with-http-info user-id auth-token pid)))
