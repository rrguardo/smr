(defproject easy-sms-api "1.0.0"
  :description "Add SMS test messages to any app with EasySMS API 
(https://easysms.4simple.org/)"
  :url "https://easysms.4simple.org/contact"
  :license {:name "Apache 2.0"
            :url "http://www.apache.org/licenses/LICENSE-2.0.html"}
  :dependencies [[org.clojure/clojure "1.7.0"]
                 [clj-http "2.0.0"]
                 [cheshire "5.5.0"]])
