using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class SMSResponse {
    
    /// <summary>
    /// The success key is returned when message was delivered ok to EasySMS system.
    /// </summary>
    /// <value>The success key is returned when message was delivered ok to EasySMS system.</value>
    [DataMember(Name="success", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "success")]
    public string Success { get; set; }

    
    /// <summary>
    /// The processing id pid returned can be used for track the SMS message status.
    /// </summary>
    /// <value>The processing id pid returned can be used for track the SMS message status.</value>
    [DataMember(Name="pid", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "pid")]
    public int? Pid { get; set; }

    

    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class SMSResponse {\n");
      
      sb.Append("  Success: ").Append(Success).Append("\n");
      
      sb.Append("  Pid: ").Append(Pid).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
