/// <reference path="api.d.ts" />

/* tslint:disable:no-unused-variable member-ordering */

namespace API.Client {
    'use strict';

    export class GetBalanceApi {
        protected basePath = 'https://api.4simple.org/';
        public defaultHeaders : any = {};

        static $inject: string[] = ['$http', '$httpParamSerializer'];

        constructor(protected $http: ng.IHttpService, protected $httpParamSerializer?: (d: any) => any, basePath?: string) {
            if (basePath) {
                this.basePath = basePath;
            }
        }

        private extendObj<T1,T2>(objA: T1, objB: T2) {
            for(let key in objB){
                if(objB.hasOwnProperty(key)){
                    objA[key] = objB[key];
                }
            }
            return <T1&T2>objA;
        }

        /**
         * Get account balance
         * Use this API endpoint to get account balance.
         * @param userId The user account id, located at user panel.
         * @param authToken The user authentication token, located at user panel.
         */
        public balancePost (userId: number, authToken: string, extraHttpRequestParams?: any ) : ng.IHttpPromise<Balance> {
            const localVarPath = this.basePath + '/balance';

            let queryParameters: any = {};
            let headerParams: any = this.extendObj({}, this.defaultHeaders);
            let formParams: any = {};

            // verify required parameter 'userId' is set
            if (!userId) {
                throw new Error('Missing required parameter userId when calling balancePost');
            }
            // verify required parameter 'authToken' is set
            if (!authToken) {
                throw new Error('Missing required parameter authToken when calling balancePost');
            }
            headerParams['Content-Type'] = 'application/x-www-form-urlencoded';

            formParams['user_id'] = userId;

            formParams['auth_token'] = authToken;

            let httpRequestParams: any = {
                method: 'POST',
                url: localVarPath,
                json: false,
                
                data: this.$httpParamSerializer(formParams),
                
                params: queryParameters,
                headers: headerParams
            };

            if (extraHttpRequestParams) {
                httpRequestParams = this.extendObj(httpRequestParams, extraHttpRequestParams);
            }

            return this.$http(httpRequestParams);
        }
    }
}
