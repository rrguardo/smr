/// <reference path="api.d.ts" />

/* tslint:disable:no-unused-variable member-ordering */

namespace API.Client {
    'use strict';

    export class SendSMSApi {
        protected basePath = 'https://api.4simple.org/';
        public defaultHeaders : any = {};

        static $inject: string[] = ['$http', '$httpParamSerializer'];

        constructor(protected $http: ng.IHttpService, protected $httpParamSerializer?: (d: any) => any, basePath?: string) {
            if (basePath) {
                this.basePath = basePath;
            }
        }

        private extendObj<T1,T2>(objA: T1, objB: T2) {
            for(let key in objB){
                if(objB.hasOwnProperty(key)){
                    objA[key] = objB[key];
                }
            }
            return <T1&T2>objA;
        }

        /**
         * Send SMS text message
         * Use this API endpoint to send SMS text messages.
         * @param userId The user account id, located at user panel.
         * @param authToken The user authentication token, located at user panel.
         * @param to The phone number where send the SMS.
         * @param body The SMS text message to send.
         */
        public smsPost (userId: number, authToken: string, to: string, body: string, extraHttpRequestParams?: any ) : ng.IHttpPromise<SMSResponse> {
            const localVarPath = this.basePath + '/sms';

            let queryParameters: any = {};
            let headerParams: any = this.extendObj({}, this.defaultHeaders);
            let formParams: any = {};

            // verify required parameter 'userId' is set
            if (!userId) {
                throw new Error('Missing required parameter userId when calling smsPost');
            }
            // verify required parameter 'authToken' is set
            if (!authToken) {
                throw new Error('Missing required parameter authToken when calling smsPost');
            }
            // verify required parameter 'to' is set
            if (!to) {
                throw new Error('Missing required parameter to when calling smsPost');
            }
            // verify required parameter 'body' is set
            if (!body) {
                throw new Error('Missing required parameter body when calling smsPost');
            }
            headerParams['Content-Type'] = 'application/x-www-form-urlencoded';

            formParams['user_id'] = userId;

            formParams['auth_token'] = authToken;

            formParams['to'] = to;

            formParams['body'] = body;

            let httpRequestParams: any = {
                method: 'POST',
                url: localVarPath,
                json: false,
                
                data: this.$httpParamSerializer(formParams),
                
                params: queryParameters,
                headers: headerParams
            };

            if (extraHttpRequestParams) {
                httpRequestParams = this.extendObj(httpRequestParams, extraHttpRequestParams);
            }

            return this.$http(httpRequestParams);
        }
    }
}
