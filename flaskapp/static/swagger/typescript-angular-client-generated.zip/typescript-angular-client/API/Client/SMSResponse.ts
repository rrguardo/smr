/// <reference path="api.d.ts" />

namespace API.Client {
    'use strict';

    export interface SMSResponse {

        /**
         * The success key is returned when message was delivered ok to EasySMS system.
         */
        "success"?: string;

        /**
         * The processing id pid returned can be used for track the SMS message status.
         */
        "pid"?: number;
    }

}
