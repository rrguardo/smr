/// <reference path="api.d.ts" />

/* tslint:disable:no-unused-variable member-ordering */

namespace API.Client {
    'use strict';

    export class SMSStatusApi {
        protected basePath = 'https://api.4simple.org/';
        public defaultHeaders : any = {};

        static $inject: string[] = ['$http', '$httpParamSerializer'];

        constructor(protected $http: ng.IHttpService, protected $httpParamSerializer?: (d: any) => any, basePath?: string) {
            if (basePath) {
                this.basePath = basePath;
            }
        }

        private extendObj<T1,T2>(objA: T1, objB: T2) {
            for(let key in objB){
                if(objB.hasOwnProperty(key)){
                    objA[key] = objB[key];
                }
            }
            return <T1&T2>objA;
        }

        /**
         * Verify SMS sent status
         * Use this API endpoint to verify SMS sent status.
         * @param userId The user account id, located at user panel.
         * @param authToken The user authentication token, located at user panel.
         * @param pid The processing id pid returned when you sent the sms.
         */
        public statusPost (userId: number, authToken: string, pid: number, extraHttpRequestParams?: any ) : ng.IHttpPromise<SMSStatus> {
            const localVarPath = this.basePath + '/status';

            let queryParameters: any = {};
            let headerParams: any = this.extendObj({}, this.defaultHeaders);
            let formParams: any = {};

            // verify required parameter 'userId' is set
            if (!userId) {
                throw new Error('Missing required parameter userId when calling statusPost');
            }
            // verify required parameter 'authToken' is set
            if (!authToken) {
                throw new Error('Missing required parameter authToken when calling statusPost');
            }
            // verify required parameter 'pid' is set
            if (!pid) {
                throw new Error('Missing required parameter pid when calling statusPost');
            }
            headerParams['Content-Type'] = 'application/x-www-form-urlencoded';

            formParams['user_id'] = userId;

            formParams['auth_token'] = authToken;

            formParams['pid'] = pid;

            let httpRequestParams: any = {
                method: 'POST',
                url: localVarPath,
                json: false,
                
                data: this.$httpParamSerializer(formParams),
                
                params: queryParameters,
                headers: headerParams
            };

            if (extraHttpRequestParams) {
                httpRequestParams = this.extendObj(httpRequestParams, extraHttpRequestParams);
            }

            return this.$http(httpRequestParams);
        }
    }
}
