/// <reference path="api.d.ts" />

namespace API.Client {
    'use strict';

    export interface Balance {

        /**
         * The user account balance.
         */
        "balance"?: number;
    }

}
