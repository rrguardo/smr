/// <reference path="api.d.ts" />

namespace API.Client {
    'use strict';

    export interface SMSStatus {

        /**
         * The SMS processing status info.\nPossible status values are:\n  - queued When the sms is in the processing queue waiting to be delivered.\n  - success-delivered The sms was delivered successful.\n  - failed The sms delivery fails.
         */
        "status"?: string;
    }

}
