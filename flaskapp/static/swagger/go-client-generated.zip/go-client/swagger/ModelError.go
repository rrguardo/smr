package swagger

import (
)

type ModelError struct {
    Error_  string  `json:"error,omitempty"`
    
}
