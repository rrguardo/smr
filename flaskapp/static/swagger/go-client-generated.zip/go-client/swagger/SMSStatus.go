package swagger

import (
)

type SMSStatus struct {
    Status  string  `json:"status,omitempty"`
    
}
