package swagger

import (
)

type Balance struct {
    Balance  float32  `json:"balance,omitempty"`
    
}
