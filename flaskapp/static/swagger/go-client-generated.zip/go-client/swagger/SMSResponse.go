package swagger

import (
)

type SMSResponse struct {
    Success  string  `json:"success,omitempty"`
    Pid  int32  `json:"pid,omitempty"`
    
}
