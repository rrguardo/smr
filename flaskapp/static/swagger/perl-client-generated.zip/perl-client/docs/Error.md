# WWW::SwaggerClient::Object::Error

## Import the module
```perl
use WWW::SwaggerClient::Object::Error;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **string** | Error description info. | [optional] 


