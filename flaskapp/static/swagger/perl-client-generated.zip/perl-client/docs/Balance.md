# WWW::SwaggerClient::Object::Balance

## Import the module
```perl
use WWW::SwaggerClient::Object::Balance;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**balance** | **double** | The user account balance. | [optional] 


