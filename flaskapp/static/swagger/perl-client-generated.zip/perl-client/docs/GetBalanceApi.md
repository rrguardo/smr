# WWW::SwaggerClient::GetBalanceApi

All URIs are relative to *https://api.4simple.org/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**balance_post**](GetBalanceApi.md#balance_post) | **POST** /balance | Get account balance


# **balance_post**
> Balance balance_post(user_id => $user_id, auth_token => $auth_token)

Get account balance

Use this API endpoint to get account balance.

### Example 
```perl
my $api = WWW::SwaggerClient::GetBalanceApi->new();
my $user_id = 56; # [int] The user account id, located at user panel.
my $auth_token = 'auth_token_example'; # [string] The user authentication token, located at user panel.

eval { 
    my $result = $api->balance_post(user_id => $user_id, auth_token => $auth_token);
};
if ($@) {
    warn "Exception when calling balance_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **int**| The user account id, located at user panel. | 
 **auth_token** | **string**| The user authentication token, located at user panel. | 

### Return type

[**Balance**](Balance.md)

### Authorization

No authorization required

### HTTP reuqest headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json



