# WWW::SwaggerClient::Object::SMSStatus

## Import the module
```perl
use WWW::SwaggerClient::Object::SMSStatus;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **string** | The SMS processing status info.\nPossible status values are:\n  - queued When the sms is in the processing queue waiting to be delivered.\n  - success-delivered The sms was delivered successful.\n  - failed The sms delivery fails. | [optional] 


