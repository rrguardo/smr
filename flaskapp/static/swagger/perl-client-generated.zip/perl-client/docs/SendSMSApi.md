# WWW::SwaggerClient::SendSMSApi

All URIs are relative to *https://api.4simple.org/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**sms_post**](SendSMSApi.md#sms_post) | **POST** /sms | Send SMS text message


# **sms_post**
> SMSResponse sms_post(user_id => $user_id, auth_token => $auth_token, to => $to, body => $body)

Send SMS text message

Use this API endpoint to send SMS text messages.

### Example 
```perl
my $api = WWW::SwaggerClient::SendSMSApi->new();
my $user_id = 56; # [int] The user account id, located at user panel.
my $auth_token = 'auth_token_example'; # [string] The user authentication token, located at user panel.
my $to = 'to_example'; # [string] The phone number where send the SMS.
my $body = 'body_example'; # [string] The SMS text message to send.

eval { 
    my $result = $api->sms_post(user_id => $user_id, auth_token => $auth_token, to => $to, body => $body);
};
if ($@) {
    warn "Exception when calling sms_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **int**| The user account id, located at user panel. | 
 **auth_token** | **string**| The user authentication token, located at user panel. | 
 **to** | **string**| The phone number where send the SMS. | 
 **body** | **string**| The SMS text message to send. | 

### Return type

[**SMSResponse**](SMSResponse.md)

### Authorization

No authorization required

### HTTP reuqest headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json



