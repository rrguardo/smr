# WWW::SwaggerClient::Object::SMSResponse

## Import the module
```perl
use WWW::SwaggerClient::Object::SMSResponse;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **string** | The success key is returned when message was delivered ok to EasySMS system. | [optional] 
**pid** | **int** | The processing id pid returned can be used for track the SMS message status. | [optional] 


