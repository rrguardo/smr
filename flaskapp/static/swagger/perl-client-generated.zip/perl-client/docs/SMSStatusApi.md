# WWW::SwaggerClient::SMSStatusApi

All URIs are relative to *https://api.4simple.org/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**status_post**](SMSStatusApi.md#status_post) | **POST** /status | Verify SMS sent status


# **status_post**
> SMSStatus status_post(user_id => $user_id, auth_token => $auth_token, pid => $pid)

Verify SMS sent status

Use this API endpoint to verify SMS sent status.

### Example 
```perl
my $api = WWW::SwaggerClient::SMSStatusApi->new();
my $user_id = 56; # [int] The user account id, located at user panel.
my $auth_token = 'auth_token_example'; # [string] The user authentication token, located at user panel.
my $pid = 56; # [int] The processing id pid returned when you sent the sms.

eval { 
    my $result = $api->status_post(user_id => $user_id, auth_token => $auth_token, pid => $pid);
};
if ($@) {
    warn "Exception when calling status_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **int**| The user account id, located at user panel. | 
 **auth_token** | **string**| The user authentication token, located at user panel. | 
 **pid** | **int**| The processing id pid returned when you sent the sms. | 

### Return type

[**SMSStatus**](SMSStatus.md)

### Authorization

No authorization required

### HTTP reuqest headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json



