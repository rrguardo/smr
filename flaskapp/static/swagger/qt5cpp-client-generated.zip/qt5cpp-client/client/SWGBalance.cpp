
#include "SWGBalance.h"

#include "SWGHelpers.h"

#include <QJsonDocument>
#include <QJsonArray>
#include <QObject>
#include <QDebug>

namespace Swagger {


SWGBalance::SWGBalance(QString* json) {
    init();
    this->fromJson(*json);
}

SWGBalance::SWGBalance() {
    init();
}

SWGBalance::~SWGBalance() {
    this->cleanup();
}

void
SWGBalance::init() {
    balance = 0.0f;
    
}

void
SWGBalance::cleanup() {
    
    
}

SWGBalance*
SWGBalance::fromJson(QString &json) {
    QByteArray array (json.toStdString().c_str());
    QJsonDocument doc = QJsonDocument::fromJson(array);
    QJsonObject jsonObject = doc.object();
    this->fromJsonObject(jsonObject);
    return this;
}

void
SWGBalance::fromJsonObject(QJsonObject &pJson) {
    setValue(&balance, pJson["balance"], "float", "");
    
}

QString
SWGBalance::asJson ()
{
    QJsonObject* obj = this->asJsonObject();
    
    QJsonDocument doc(*obj);
    QByteArray bytes = doc.toJson();
    return QString(bytes);
}

QJsonObject*
SWGBalance::asJsonObject() {
    QJsonObject* obj = new QJsonObject();
    obj->insert("balance", QJsonValue(balance));
    

    return obj;
}

float
SWGBalance::getBalance() {
    return balance;
}
void
SWGBalance::setBalance(float balance) {
    this->balance = balance;
}



} /* namespace Swagger */

