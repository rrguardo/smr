#ifndef _SWG_SWGSendSMSApi_H_
#define _SWG_SWGSendSMSApi_H_

#include "SWGHttpRequest.h"

#include <QString>
#include "SWGSMSResponse.h"
#include "SWGError.h"

#include <QObject>

namespace Swagger {

class SWGSendSMSApi: public QObject {
    Q_OBJECT

public:
    SWGSendSMSApi();
    SWGSendSMSApi(QString host, QString basePath);
    ~SWGSendSMSApi();

    QString host;
    QString basePath;

    void smsPost(qint32 userId, QString* authToken, QString* to, QString* body);
    
private:
    void smsPostCallback (HttpRequestWorker * worker);
    
signals:
    void smsPostSignal(SWGSMSResponse* summary);
    
};
}
#endif