
#include "SWGSMS_Status.h"

#include "SWGHelpers.h"

#include <QJsonDocument>
#include <QJsonArray>
#include <QObject>
#include <QDebug>

namespace Swagger {


SWGSMS_Status::SWGSMS_Status(QString* json) {
    init();
    this->fromJson(*json);
}

SWGSMS_Status::SWGSMS_Status() {
    init();
}

SWGSMS_Status::~SWGSMS_Status() {
    this->cleanup();
}

void
SWGSMS_Status::init() {
    status = new QString("");
    
}

void
SWGSMS_Status::cleanup() {
    if(status != NULL) {
        delete status;
    }
    
}

SWGSMS_Status*
SWGSMS_Status::fromJson(QString &json) {
    QByteArray array (json.toStdString().c_str());
    QJsonDocument doc = QJsonDocument::fromJson(array);
    QJsonObject jsonObject = doc.object();
    this->fromJsonObject(jsonObject);
    return this;
}

void
SWGSMS_Status::fromJsonObject(QJsonObject &pJson) {
    setValue(&status, pJson["status"], "QString", "QString");
    
}

QString
SWGSMS_Status::asJson ()
{
    QJsonObject* obj = this->asJsonObject();
    
    QJsonDocument doc(*obj);
    QByteArray bytes = doc.toJson();
    return QString(bytes);
}

QJsonObject*
SWGSMS_Status::asJsonObject() {
    QJsonObject* obj = new QJsonObject();
    
    
    toJsonValue(QString("status"), status, obj, QString("QString"));
    
    
    
    

    return obj;
}

QString*
SWGSMS_Status::getStatus() {
    return status;
}
void
SWGSMS_Status::setStatus(QString* status) {
    this->status = status;
}



} /* namespace Swagger */

