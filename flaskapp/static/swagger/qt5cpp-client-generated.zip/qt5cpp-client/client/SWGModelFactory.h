#ifndef ModelFactory_H_
#define ModelFactory_H_


#include "SWGBalance.h"
#include "SWGError.h"
#include "SWGSMSResponse.h"
#include "SWGSMS_Status.h"

namespace Swagger {
  inline void* create(QString type) {
    if(QString("SWGBalance").compare(type) == 0) {
      return new SWGBalance();
    }
    if(QString("SWGError").compare(type) == 0) {
      return new SWGError();
    }
    if(QString("SWGSMSResponse").compare(type) == 0) {
      return new SWGSMSResponse();
    }
    if(QString("SWGSMS_Status").compare(type) == 0) {
      return new SWGSMS_Status();
    }
    
    return NULL;
  }

  inline void* create(QString json, QString type) {
    void* val = create(type);
    if(val != NULL) {
      SWGObject* obj = static_cast<SWGObject*>(val);
      return obj->fromJson(json);
    }
    if(type.startsWith("QString")) {
      return new QString();
    }
    return NULL;
  }
} /* namespace Swagger */

#endif /* ModelFactory_H_ */
