/*
 * SWGSMSResponse.h
 * 
 * 
 */

#ifndef SWGSMSResponse_H_
#define SWGSMSResponse_H_

#include <QJsonObject>


#include <QString>

#include "SWGObject.h"


namespace Swagger {

class SWGSMSResponse: public SWGObject {
public:
    SWGSMSResponse();
    SWGSMSResponse(QString* json);
    virtual ~SWGSMSResponse();
    void init();
    void cleanup();

    QString asJson ();
    QJsonObject* asJsonObject();
    void fromJsonObject(QJsonObject &json);
    SWGSMSResponse* fromJson(QString &jsonString);

    QString* getSuccess();
    void setSuccess(QString* success);
    qint32 getPid();
    void setPid(qint32 pid);
    

private:
    QString* success;
    qint32 pid;
    
};

} /* namespace Swagger */

#endif /* SWGSMSResponse_H_ */
