#ifndef _SWG_SWGGetBalanceApi_H_
#define _SWG_SWGGetBalanceApi_H_

#include "SWGHttpRequest.h"

#include <QString>
#include "SWGBalance.h"
#include "SWGError.h"

#include <QObject>

namespace Swagger {

class SWGGetBalanceApi: public QObject {
    Q_OBJECT

public:
    SWGGetBalanceApi();
    SWGGetBalanceApi(QString host, QString basePath);
    ~SWGGetBalanceApi();

    QString host;
    QString basePath;

    void balancePost(qint32 userId, QString* authToken);
    
private:
    void balancePostCallback (HttpRequestWorker * worker);
    
signals:
    void balancePostSignal(SWGBalance* summary);
    
};
}
#endif