#include "SWGSendSMSApi.h"
#include "SWGHelpers.h"
#include "SWGModelFactory.h"

#include <QJsonArray>
#include <QJsonDocument>

namespace Swagger {
SWGSendSMSApi::SWGSendSMSApi() {}

SWGSendSMSApi::~SWGSendSMSApi() {}

SWGSendSMSApi::SWGSendSMSApi(QString host, QString basePath) {
    this->host = host;
    this->basePath = basePath;
}

void
SWGSendSMSApi::smsPost(qint32 userId, QString* authToken, QString* to, QString* body) {
    QString fullPath;
    fullPath.append(this->host).append(this->basePath).append("/sms");

    

    

    HttpRequestWorker *worker = new HttpRequestWorker();
    HttpRequestInput input(fullPath, "POST");

    if (userId != NULL) {
        input.add_var("userId", *userId);
    }
    if (authToken != NULL) {
        input.add_var("authToken", *authToken);
    }
    if (to != NULL) {
        input.add_var("to", *to);
    }
    if (body != NULL) {
        input.add_var("body", *body);
    }
    

    

    

    connect(worker,
            &HttpRequestWorker::on_execution_finished,
            this,
            &SWGSendSMSApi::smsPostCallback);

    worker->execute(&input);
}

void
SWGSendSMSApi::smsPostCallback(HttpRequestWorker * worker) {
    QString msg;
    if (worker->error_type == QNetworkReply::NoError) {
        msg = QString("Success! %1 bytes").arg(worker->response.length());
    }
    else {
        msg = "Error: " + worker->error_str;
    }

    

    
    
    
    QString json(worker->response);
    SWGSMSResponse* output = static_cast<SWGSMSResponse*>(create(json, QString("SWGSMSResponse")));
    
    
    

    worker->deleteLater();

    emit smsPostSignal(output);
    
}
} /* namespace Swagger */
