/*
 * SWGError.h
 * 
 * 
 */

#ifndef SWGError_H_
#define SWGError_H_

#include <QJsonObject>


#include <QString>

#include "SWGObject.h"


namespace Swagger {

class SWGError: public SWGObject {
public:
    SWGError();
    SWGError(QString* json);
    virtual ~SWGError();
    void init();
    void cleanup();

    QString asJson ();
    QJsonObject* asJsonObject();
    void fromJsonObject(QJsonObject &json);
    SWGError* fromJson(QString &jsonString);

    QString* getError();
    void setError(QString* error);
    

private:
    QString* error;
    
};

} /* namespace Swagger */

#endif /* SWGError_H_ */
