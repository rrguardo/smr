#ifndef _SWG_SWGSMSStatusApi_H_
#define _SWG_SWGSMSStatusApi_H_

#include "SWGHttpRequest.h"

#include <QString>
#include "SWGSMS_Status.h"
#include "SWGError.h"

#include <QObject>

namespace Swagger {

class SWGSMSStatusApi: public QObject {
    Q_OBJECT

public:
    SWGSMSStatusApi();
    SWGSMSStatusApi(QString host, QString basePath);
    ~SWGSMSStatusApi();

    QString host;
    QString basePath;

    void statusPost(qint32 userId, QString* authToken, qint32 pid);
    
private:
    void statusPostCallback (HttpRequestWorker * worker);
    
signals:
    void statusPostSignal(SWGSMS_Status* summary);
    
};
}
#endif