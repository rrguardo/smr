/*
 * SWGBalance.h
 * 
 * 
 */

#ifndef SWGBalance_H_
#define SWGBalance_H_

#include <QJsonObject>



#include "SWGObject.h"


namespace Swagger {

class SWGBalance: public SWGObject {
public:
    SWGBalance();
    SWGBalance(QString* json);
    virtual ~SWGBalance();
    void init();
    void cleanup();

    QString asJson ();
    QJsonObject* asJsonObject();
    void fromJsonObject(QJsonObject &json);
    SWGBalance* fromJson(QString &jsonString);

    float getBalance();
    void setBalance(float balance);
    

private:
    float balance;
    
};

} /* namespace Swagger */

#endif /* SWGBalance_H_ */
