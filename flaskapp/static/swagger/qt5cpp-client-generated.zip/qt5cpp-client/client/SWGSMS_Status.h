/*
 * SWGSMS_Status.h
 * 
 * 
 */

#ifndef SWGSMS_Status_H_
#define SWGSMS_Status_H_

#include <QJsonObject>


#include <QString>

#include "SWGObject.h"


namespace Swagger {

class SWGSMS_Status: public SWGObject {
public:
    SWGSMS_Status();
    SWGSMS_Status(QString* json);
    virtual ~SWGSMS_Status();
    void init();
    void cleanup();

    QString asJson ();
    QJsonObject* asJsonObject();
    void fromJsonObject(QJsonObject &json);
    SWGSMS_Status* fromJson(QString &jsonString);

    QString* getStatus();
    void setStatus(QString* status);
    

private:
    QString* status;
    
};

} /* namespace Swagger */

#endif /* SWGSMS_Status_H_ */
