
#include "SWGSMSResponse.h"

#include "SWGHelpers.h"

#include <QJsonDocument>
#include <QJsonArray>
#include <QObject>
#include <QDebug>

namespace Swagger {


SWGSMSResponse::SWGSMSResponse(QString* json) {
    init();
    this->fromJson(*json);
}

SWGSMSResponse::SWGSMSResponse() {
    init();
}

SWGSMSResponse::~SWGSMSResponse() {
    this->cleanup();
}

void
SWGSMSResponse::init() {
    success = new QString("");
    pid = 0;
    
}

void
SWGSMSResponse::cleanup() {
    if(success != NULL) {
        delete success;
    }
    
    
}

SWGSMSResponse*
SWGSMSResponse::fromJson(QString &json) {
    QByteArray array (json.toStdString().c_str());
    QJsonDocument doc = QJsonDocument::fromJson(array);
    QJsonObject jsonObject = doc.object();
    this->fromJsonObject(jsonObject);
    return this;
}

void
SWGSMSResponse::fromJsonObject(QJsonObject &pJson) {
    setValue(&success, pJson["success"], "QString", "QString");
    setValue(&pid, pJson["pid"], "qint32", "");
    
}

QString
SWGSMSResponse::asJson ()
{
    QJsonObject* obj = this->asJsonObject();
    
    QJsonDocument doc(*obj);
    QByteArray bytes = doc.toJson();
    return QString(bytes);
}

QJsonObject*
SWGSMSResponse::asJsonObject() {
    QJsonObject* obj = new QJsonObject();
    
    
    toJsonValue(QString("success"), success, obj, QString("QString"));
    
    
    
    obj->insert("pid", QJsonValue(pid));
    

    return obj;
}

QString*
SWGSMSResponse::getSuccess() {
    return success;
}
void
SWGSMSResponse::setSuccess(QString* success) {
    this->success = success;
}

qint32
SWGSMSResponse::getPid() {
    return pid;
}
void
SWGSMSResponse::setPid(qint32 pid) {
    this->pid = pid;
}



} /* namespace Swagger */

