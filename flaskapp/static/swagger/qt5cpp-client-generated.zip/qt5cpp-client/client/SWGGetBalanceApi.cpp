#include "SWGGetBalanceApi.h"
#include "SWGHelpers.h"
#include "SWGModelFactory.h"

#include <QJsonArray>
#include <QJsonDocument>

namespace Swagger {
SWGGetBalanceApi::SWGGetBalanceApi() {}

SWGGetBalanceApi::~SWGGetBalanceApi() {}

SWGGetBalanceApi::SWGGetBalanceApi(QString host, QString basePath) {
    this->host = host;
    this->basePath = basePath;
}

void
SWGGetBalanceApi::balancePost(qint32 userId, QString* authToken) {
    QString fullPath;
    fullPath.append(this->host).append(this->basePath).append("/balance");

    

    

    HttpRequestWorker *worker = new HttpRequestWorker();
    HttpRequestInput input(fullPath, "POST");

    if (userId != NULL) {
        input.add_var("userId", *userId);
    }
    if (authToken != NULL) {
        input.add_var("authToken", *authToken);
    }
    

    

    

    connect(worker,
            &HttpRequestWorker::on_execution_finished,
            this,
            &SWGGetBalanceApi::balancePostCallback);

    worker->execute(&input);
}

void
SWGGetBalanceApi::balancePostCallback(HttpRequestWorker * worker) {
    QString msg;
    if (worker->error_type == QNetworkReply::NoError) {
        msg = QString("Success! %1 bytes").arg(worker->response.length());
    }
    else {
        msg = "Error: " + worker->error_str;
    }

    

    
    
    
    QString json(worker->response);
    SWGBalance* output = static_cast<SWGBalance*>(create(json, QString("SWGBalance")));
    
    
    

    worker->deleteLater();

    emit balancePostSignal(output);
    
}
} /* namespace Swagger */
