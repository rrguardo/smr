#include "SWGSMSStatusApi.h"
#include "SWGHelpers.h"
#include "SWGModelFactory.h"

#include <QJsonArray>
#include <QJsonDocument>

namespace Swagger {
SWGSMSStatusApi::SWGSMSStatusApi() {}

SWGSMSStatusApi::~SWGSMSStatusApi() {}

SWGSMSStatusApi::SWGSMSStatusApi(QString host, QString basePath) {
    this->host = host;
    this->basePath = basePath;
}

void
SWGSMSStatusApi::statusPost(qint32 userId, QString* authToken, qint32 pid) {
    QString fullPath;
    fullPath.append(this->host).append(this->basePath).append("/status");

    

    

    HttpRequestWorker *worker = new HttpRequestWorker();
    HttpRequestInput input(fullPath, "POST");

    if (userId != NULL) {
        input.add_var("userId", *userId);
    }
    if (authToken != NULL) {
        input.add_var("authToken", *authToken);
    }
    if (pid != NULL) {
        input.add_var("pid", *pid);
    }
    

    

    

    connect(worker,
            &HttpRequestWorker::on_execution_finished,
            this,
            &SWGSMSStatusApi::statusPostCallback);

    worker->execute(&input);
}

void
SWGSMSStatusApi::statusPostCallback(HttpRequestWorker * worker) {
    QString msg;
    if (worker->error_type == QNetworkReply::NoError) {
        msg = QString("Success! %1 bytes").arg(worker->response.length());
    }
    else {
        msg = "Error: " + worker->error_str;
    }

    

    
    
    
    QString json(worker->response);
    SWGSMS_Status* output = static_cast<SWGSMS_Status*>(create(json, QString("SWGSMS_Status")));
    
    
    

    worker->deleteLater();

    emit statusPostSignal(output);
    
}
} /* namespace Swagger */
