
#include "SWGError.h"

#include "SWGHelpers.h"

#include <QJsonDocument>
#include <QJsonArray>
#include <QObject>
#include <QDebug>

namespace Swagger {


SWGError::SWGError(QString* json) {
    init();
    this->fromJson(*json);
}

SWGError::SWGError() {
    init();
}

SWGError::~SWGError() {
    this->cleanup();
}

void
SWGError::init() {
    error = new QString("");
    
}

void
SWGError::cleanup() {
    if(error != NULL) {
        delete error;
    }
    
}

SWGError*
SWGError::fromJson(QString &json) {
    QByteArray array (json.toStdString().c_str());
    QJsonDocument doc = QJsonDocument::fromJson(array);
    QJsonObject jsonObject = doc.object();
    this->fromJsonObject(jsonObject);
    return this;
}

void
SWGError::fromJsonObject(QJsonObject &pJson) {
    setValue(&error, pJson["error"], "QString", "QString");
    
}

QString
SWGError::asJson ()
{
    QJsonObject* obj = this->asJsonObject();
    
    QJsonDocument doc(*obj);
    QByteArray bytes = doc.toJson();
    return QString(bytes);
}

QJsonObject*
SWGError::asJsonObject() {
    QJsonObject* obj = new QJsonObject();
    
    
    toJsonValue(QString("error"), error, obj, QString("QString"));
    
    
    
    

    return obj;
}

QString*
SWGError::getError() {
    return error;
}
void
SWGError::setError(QString* error) {
    this->error = error;
}



} /* namespace Swagger */

