(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient', '../model/SMSStatus', '../model/Error'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'), require('../model/SMSStatus'), require('../model/Error'));
  } else {
    // Browser globals (root is window)
    if (!root.EasySmsApi) {
      root.EasySmsApi = {};
    }
    root.EasySmsApi.SMSStatusApi = factory(root.EasySmsApi.ApiClient, root.EasySmsApi.SMSStatus, root.EasySmsApi.Error);
  }
}(this, function(ApiClient, SMSStatus, Error) {
  'use strict';

  var SMSStatusApi = function SMSStatusApi(apiClient) {
    this.apiClient = apiClient || ApiClient.default;

    var self = this;
    
    
    /**
     * Verify SMS sent status
     * Use this API endpoint to verify SMS sent status.
     * @param {Integer} userId The user account id, located at user panel.
     * @param {String} authToken The user authentication token, located at user panel.
     * @param {Integer} pid The processing id pid returned when you sent the sms.
     * @param {function} callback the callback function, accepting three arguments: error, data, response
     *   data is of type: SMSStatus
     */
    self.statusPost = function(userId, authToken, pid, callback) {
      var postBody = null;
      
      // verify the required parameter 'userId' is set
      if (userId == null) {
        throw "Missing the required parameter 'userId' when calling statusPost";
      }
      
      // verify the required parameter 'authToken' is set
      if (authToken == null) {
        throw "Missing the required parameter 'authToken' when calling statusPost";
      }
      
      // verify the required parameter 'pid' is set
      if (pid == null) {
        throw "Missing the required parameter 'pid' when calling statusPost";
      }
      

      var pathParams = {
      };
      var queryParams = {
      };
      var headerParams = {
      };
      var formParams = {
        'user_id': userId,
        'auth_token': authToken,
        'pid': pid
      };

      var authNames = [];
      var contentTypes = ['application/x-www-form-urlencoded'];
      var accepts = ['application/json'];
      var returnType = SMSStatus;

      return this.apiClient.callApi(
        '/status', 'POST',
        pathParams, queryParams, headerParams, formParams, postBody,
        authNames, contentTypes, accepts, returnType, callback
      );

    }
    
    
  };

  return SMSStatusApi;
}));
