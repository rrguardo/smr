(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient', '../model/SMSResponse', '../model/Error'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'), require('../model/SMSResponse'), require('../model/Error'));
  } else {
    // Browser globals (root is window)
    if (!root.EasySmsApi) {
      root.EasySmsApi = {};
    }
    root.EasySmsApi.SendSMSApi = factory(root.EasySmsApi.ApiClient, root.EasySmsApi.SMSResponse, root.EasySmsApi.Error);
  }
}(this, function(ApiClient, SMSResponse, Error) {
  'use strict';

  var SendSMSApi = function SendSMSApi(apiClient) {
    this.apiClient = apiClient || ApiClient.default;

    var self = this;
    
    
    /**
     * Send SMS text message
     * Use this API endpoint to send SMS text messages.
     * @param {Integer} userId The user account id, located at user panel.
     * @param {String} authToken The user authentication token, located at user panel.
     * @param {String} to The phone number where send the SMS.
     * @param {String} body The SMS text message to send.
     * @param {function} callback the callback function, accepting three arguments: error, data, response
     *   data is of type: SMSResponse
     */
    self.smsPost = function(userId, authToken, to, body, callback) {
      var postBody = null;
      
      // verify the required parameter 'userId' is set
      if (userId == null) {
        throw "Missing the required parameter 'userId' when calling smsPost";
      }
      
      // verify the required parameter 'authToken' is set
      if (authToken == null) {
        throw "Missing the required parameter 'authToken' when calling smsPost";
      }
      
      // verify the required parameter 'to' is set
      if (to == null) {
        throw "Missing the required parameter 'to' when calling smsPost";
      }
      
      // verify the required parameter 'body' is set
      if (body == null) {
        throw "Missing the required parameter 'body' when calling smsPost";
      }
      

      var pathParams = {
      };
      var queryParams = {
      };
      var headerParams = {
      };
      var formParams = {
        'user_id': userId,
        'auth_token': authToken,
        'to': to,
        'body': body
      };

      var authNames = [];
      var contentTypes = ['application/x-www-form-urlencoded'];
      var accepts = ['application/json'];
      var returnType = SMSResponse;

      return this.apiClient.callApi(
        '/sms', 'POST',
        pathParams, queryParams, headerParams, formParams, postBody,
        authNames, contentTypes, accepts, returnType, callback
      );

    }
    
    
  };

  return SendSMSApi;
}));
