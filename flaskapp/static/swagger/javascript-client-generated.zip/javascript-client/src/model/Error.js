(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'));
  } else {
    // Browser globals (root is window)
    if (!root.EasySmsApi) {
      root.EasySmsApi = {};
    }
    root.EasySmsApi.Error = factory(root.EasySmsApi.ApiClient);
  }
}(this, function(ApiClient) {
  'use strict';
  
  
  var Error = function Error() { 
    
  };

  Error.constructFromObject = function(data) {
    if (!data) {
      return null;
    }
    var _this = new Error();
    
    if (data['error']) {
      _this['error'] = ApiClient.convertToType(data['error'], 'String');
    }
    
    return _this;
  }

  
  
  /**
   * get Error description info.
   * @return {String}
   **/
  Error.prototype.getError = function() {
    return this['error'];
  }

  /**
   * set Error description info.
   * @param {String} error
   **/
  Error.prototype.setError = function(error) {
    this['error'] = error;
  }
  
  

  

  return Error;
  
  
}));
