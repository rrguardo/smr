(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'));
  } else {
    // Browser globals (root is window)
    if (!root.EasySmsApi) {
      root.EasySmsApi = {};
    }
    root.EasySmsApi.SMSResponse = factory(root.EasySmsApi.ApiClient);
  }
}(this, function(ApiClient) {
  'use strict';
  
  
  var SMSResponse = function SMSResponse() { 
    
  };

  SMSResponse.constructFromObject = function(data) {
    if (!data) {
      return null;
    }
    var _this = new SMSResponse();
    
    if (data['success']) {
      _this['success'] = ApiClient.convertToType(data['success'], 'String');
    }
    
    if (data['pid']) {
      _this['pid'] = ApiClient.convertToType(data['pid'], 'Integer');
    }
    
    return _this;
  }

  
  
  /**
   * get The success key is returned when message was delivered ok to EasySMS system.
   * @return {String}
   **/
  SMSResponse.prototype.getSuccess = function() {
    return this['success'];
  }

  /**
   * set The success key is returned when message was delivered ok to EasySMS system.
   * @param {String} success
   **/
  SMSResponse.prototype.setSuccess = function(success) {
    this['success'] = success;
  }
  
  /**
   * get The processing id pid returned can be used for track the SMS message status.
   * @return {Integer}
   **/
  SMSResponse.prototype.getPid = function() {
    return this['pid'];
  }

  /**
   * set The processing id pid returned can be used for track the SMS message status.
   * @param {Integer} pid
   **/
  SMSResponse.prototype.setPid = function(pid) {
    this['pid'] = pid;
  }
  
  

  

  return SMSResponse;
  
  
}));
