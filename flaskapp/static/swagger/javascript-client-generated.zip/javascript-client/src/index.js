(function(factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['./ApiClient', './model/Balance', './model/Error', './model/SMSResponse', './model/SMSStatus', './api/GetBalanceApi', './api/SMSStatusApi', './api/SendSMSApi'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('./ApiClient'), require('./model/Balance'), require('./model/Error'), require('./model/SMSResponse'), require('./model/SMSStatus'), require('./api/GetBalanceApi'), require('./api/SMSStatusApi'), require('./api/SendSMSApi'));
  }
}(function(ApiClient, Balance, Error, SMSResponse, SMSStatus, GetBalanceApi, SMSStatusApi, SendSMSApi) {
  'use strict';

  return {
    ApiClient: ApiClient,
    Balance: Balance,
    Error: Error,
    SMSResponse: SMSResponse,
    SMSStatus: SMSStatus,
    GetBalanceApi: GetBalanceApi,
    SMSStatusApi: SMSStatusApi,
    SendSMSApi: SendSMSApi
  };
}));
