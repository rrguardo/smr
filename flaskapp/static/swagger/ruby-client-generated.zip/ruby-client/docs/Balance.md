# SwaggerClient::Balance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**balance** | **Float** | The user account balance. | [optional] 


