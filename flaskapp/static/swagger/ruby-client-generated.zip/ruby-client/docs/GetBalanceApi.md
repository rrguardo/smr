# SwaggerClient::GetBalanceApi

All URIs are relative to *https://api.4simple.org/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**balance_post**](GetBalanceApi.md#balance_post) | **POST** /balance | Get account balance


# **balance_post**
> Balance balance_post(user_id, auth_token)

Get account balance

Use this API endpoint to get account balance.

### Example
```ruby
api = SwaggerClient::GetBalanceApi.new

user_id = 56 # [Integer] The user account id, located at user panel.

auth_token = "auth_token_example" # [String] The user authentication token, located at user panel.


begin
  result = api.balance_post(user_id, auth_token)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling balance_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **Integer**| The user account id, located at user panel. | 
 **auth_token** | **String**| The user authentication token, located at user panel. | 

### Return type

[**Balance**](Balance.md)

### Authorization

No authorization required

### HTTP reuqest headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json



