# SwaggerClient::SMSStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | The SMS processing status info.\nPossible status values are:\n  - queued When the sms is in the processing queue waiting to be delivered.\n  - success-delivered The sms was delivered successful.\n  - failed The sms delivery fails. | [optional] 


