# SwaggerClient::Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** | Error description info. | [optional] 


