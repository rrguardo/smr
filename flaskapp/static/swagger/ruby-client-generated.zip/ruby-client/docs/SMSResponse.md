# SwaggerClient::SMSResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **String** | The success key is returned when message was delivered ok to EasySMS system. | [optional] 
**pid** | **Integer** | The processing id pid returned can be used for track the SMS message status. | [optional] 


