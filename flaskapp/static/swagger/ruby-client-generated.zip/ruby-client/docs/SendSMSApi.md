# SwaggerClient::SendSMSApi

All URIs are relative to *https://api.4simple.org/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**sms_post**](SendSMSApi.md#sms_post) | **POST** /sms | Send SMS text message


# **sms_post**
> SMSResponse sms_post(user_id, auth_token, to, body)

Send SMS text message

Use this API endpoint to send SMS text messages.

### Example
```ruby
api = SwaggerClient::SendSMSApi.new

user_id = 56 # [Integer] The user account id, located at user panel.

auth_token = "auth_token_example" # [String] The user authentication token, located at user panel.

to = "to_example" # [String] The phone number where send the SMS.

body = "body_example" # [String] The SMS text message to send.


begin
  result = api.sms_post(user_id, auth_token, to, body)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling sms_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **Integer**| The user account id, located at user panel. | 
 **auth_token** | **String**| The user authentication token, located at user panel. | 
 **to** | **String**| The phone number where send the SMS. | 
 **body** | **String**| The SMS text message to send. | 

### Return type

[**SMSResponse**](SMSResponse.md)

### Authorization

No authorization required

### HTTP reuqest headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json



