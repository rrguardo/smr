# SwaggerClient::SMSStatusApi

All URIs are relative to *https://api.4simple.org/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**status_post**](SMSStatusApi.md#status_post) | **POST** /status | Verify SMS sent status


# **status_post**
> SMSStatus status_post(user_id, auth_token, pid)

Verify SMS sent status

Use this API endpoint to verify SMS sent status.

### Example
```ruby
api = SwaggerClient::SMSStatusApi.new

user_id = 56 # [Integer] The user account id, located at user panel.

auth_token = "auth_token_example" # [String] The user authentication token, located at user panel.

pid = 56 # [Integer] The processing id pid returned when you sent the sms.


begin
  result = api.status_post(user_id, auth_token, pid)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling status_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **Integer**| The user account id, located at user panel. | 
 **auth_token** | **String**| The user authentication token, located at user panel. | 
 **pid** | **Integer**| The processing id pid returned when you sent the sms. | 

### Return type

[**SMSStatus**](SMSStatus.md)

### Authorization

No authorization required

### HTTP reuqest headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json



