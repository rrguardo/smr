package io.swagger.client.model

import org.joda.time.DateTime


case class SMS_Status (
  status: String  // The SMS processing status info.\nPossible status values are:\n  - queued When the sms is in the processing queue waiting to be delivered.\n  - success-delivered The sms was delivered successful.\n  - failed The sms delivery fails.
  
)
