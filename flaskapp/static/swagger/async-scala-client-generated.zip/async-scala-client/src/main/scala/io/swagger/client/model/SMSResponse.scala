package io.swagger.client.model

import org.joda.time.DateTime


case class SMSResponse (
  success: String,  // The success key is returned when message was delivered ok to EasySMS system.
  pid: Integer  // The processing id pid returned can be used for track the SMS message status.
  
)
