package io.swagger.client.model

import org.joda.time.DateTime


case class Balance (
  balance: Float  // The user account balance.
  
)
