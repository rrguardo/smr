package io.swagger.client.model

import org.joda.time.DateTime


case class Error (
  error: String  // Error description info.
  
)
