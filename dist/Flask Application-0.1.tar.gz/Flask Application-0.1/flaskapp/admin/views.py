# -*- coding: utf-8 -*-
"""
    flaskapp.admin.views
    ~~~~~~~~~~~~~~~~~~~~

    Admin views here.
"""

from flask import request, session, g, redirect, url_for, \
    abort, render_template
from jinja2 import TemplateNotFound
from flask.ext.babel import lazy_gettext


#@admin_bp.route('/', defaults={'page': 'index'})
#@admin_bp.route('/<page>')
def show(page):
    """ Default admin index page."""
    try:
        return render_template('admin/admin.html', page_name=page,
                               title=lazy_gettext(u"Admin title"))
    except TemplateNotFound:
        abort(404)
