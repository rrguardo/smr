# -*- coding: utf-8 -*-
"""
    flaskapp.admin.urls
    ~~~~~~~~~~~~~~~~~~~
    
    Add all url <-> view maps here for admin sub-package.
"""

from flaskapp.lazyhelpers import MultiUrls
from flaskapp.admin import admin_bp


#Lazy-optimized blueprint views load here
admin_bp_lz = MultiUrls('admin.views.show', admin_bp)
admin_bp_lz.add_url_rule('/<page>')
admin_bp_lz.add_url_rule('/', defaults={'page': 'index'} )
