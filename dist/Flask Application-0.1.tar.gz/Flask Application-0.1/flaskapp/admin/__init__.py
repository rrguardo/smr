# -*- coding: utf-8 -*-
"""
    flaskapp.admin
    ~~~~~~~~~~~~~~

    Admin package here.
"""


from flask import Blueprint


admin_bp = Blueprint('admin', __name__, template_folder='templates',
            static_folder='static')

# Views import here >>
#lazy-optimized views load
import flaskapp.admin.urls
