# -*- coding: utf-8 -*-
"""
    flaskapp.model
    ~~~~~~~~~~~~~~
    
    SQLAlchemy database models.
"""

from flaskapp import db

class Comments(db.Model):
    """ System users model"""
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.String(200))
